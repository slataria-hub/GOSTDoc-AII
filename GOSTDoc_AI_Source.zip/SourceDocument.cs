using System;

namespace GOSTDoc.Core;
public class SourceDocument
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProjectId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string FileHash { get; set; } = string.Empty;
    public string Status { get; set; } = "Ожидает";
    public string ExtractedText { get; set; } = string.Empty;
}