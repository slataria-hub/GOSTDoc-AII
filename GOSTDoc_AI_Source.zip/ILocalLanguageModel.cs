using System.Threading.Tasks;
namespace GOSTDoc.Core;
public interface ILocalLanguageModel
{
    Task<string> GenerateAsync(string prompt);
}