using System;
using System.IO;
using GOSTDoc.Core;

namespace GOSTDoc.Infrastructure;
public class TxtExtractor : ITextExtractor
{
    public bool CanExtract(string filePath) => filePath.EndsWith(".txt", StringComparison.OrdinalIgnoreCase);
    public string ExtractText(string filePath) => File.ReadAllText(filePath);
}