namespace GOSTDoc.Core;
public interface IDocumentExporter
{
    void ExportToDocx(string text, string filePath);
}