using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using GOSTDoc.Core;

namespace GOSTDoc.Infrastructure;
public class SqliteSourceDocumentRepository : ISourceDocumentRepository
{
    private readonly string _connectionString;
    public SqliteSourceDocumentRepository(string dbPath) => _connectionString = $"Data Source={dbPath}";

    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = @"
            CREATE TABLE IF NOT EXISTS SourceDocuments (
                Id TEXT PRIMARY KEY,
                ProjectId TEXT NOT NULL,
                FileName TEXT NOT NULL,
                FileHash TEXT NOT NULL,
                Status TEXT NOT NULL,
                ExtractedText TEXT
            );";
        await command.ExecuteNonQueryAsync();
    }

    public async Task AddAsync(SourceDocument doc)
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = "INSERT INTO SourceDocuments (Id, ProjectId, FileName, FileHash, Status, ExtractedText) VALUES ($id, $proj, $name, $hash, $status, $text);";
        command.Parameters.AddWithValue("$id", doc.Id.ToString());
        command.Parameters.AddWithValue("$proj", doc.ProjectId.ToString());
        command.Parameters.AddWithValue("$name", doc.FileName);
        command.Parameters.AddWithValue("$hash", doc.FileHash);
        command.Parameters.AddWithValue("$status", doc.Status);
        command.Parameters.AddWithValue("$text", doc.ExtractedText);
        await command.ExecuteNonQueryAsync();
    }

    public async Task<IEnumerable<SourceDocument>> GetByProjectIdAsync(Guid projectId)
    {
        var docs = new List<SourceDocument>();
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, ProjectId, FileName, FileHash, Status, ExtractedText FROM SourceDocuments WHERE ProjectId = $proj;";
        command.Parameters.AddWithValue("$proj", projectId.ToString());
        using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            docs.Add(new SourceDocument
            {
                Id = Guid.Parse(reader.GetString(0)),
                ProjectId = Guid.Parse(reader.GetString(1)),
                FileName = reader.GetString(2),
                FileHash = reader.GetString(3),
                Status = reader.GetString(4),
                ExtractedText = reader.GetString(5)
            });
        }
        return docs;
    }
}