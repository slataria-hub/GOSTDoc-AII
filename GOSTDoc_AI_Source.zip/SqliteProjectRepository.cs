using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GOSTDoc.Core;
namespace GOSTDoc.Infrastructure;
public class SqliteProjectRepository : IProjectRepository
{
    private readonly string _connectionString;
    public SqliteProjectRepository(string dbPath) => _connectionString = $"Data Source={dbPath}";
    
    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = @"
            CREATE TABLE IF NOT EXISTS Projects (
                Id TEXT PRIMARY KEY, Name TEXT NOT NULL, Description TEXT, 
                CreatedAt TEXT NOT NULL, LocalPath TEXT NOT NULL, IsArchived INTEGER DEFAULT 0
            );";
        await command.ExecuteNonQueryAsync();
    }

    public async Task<Project> CreateProjectAsync(string name, string description, string path)
    {
        var project = new Project { Name = name, Description = description, LocalPath = path };
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = "INSERT INTO Projects (Id, Name, Description, CreatedAt, LocalPath, IsArchived) VALUES ($id, $name, $desc, $date, $path, 0);";
        command.Parameters.AddWithValue("$id", project.Id.ToString());
        command.Parameters.AddWithValue("$name", project.Name);
        command.Parameters.AddWithValue("$desc", project.Description);
        command.Parameters.AddWithValue("$date", project.CreatedAt.ToString("O"));
        command.Parameters.AddWithValue("$path", project.LocalPath);
        await command.ExecuteNonQueryAsync();
        return project;
    }

    public async Task<IEnumerable<Project>> GetAllProjectsAsync()
    {
        var projects = new List<Project>();
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, Name, Description, CreatedAt, LocalPath, IsArchived FROM Projects;";
        using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            projects.Add(new Project { 
                Id = Guid.Parse(reader.GetString(0)), Name = reader.GetString(1), 
                Description = reader.GetString(2), CreatedAt = DateTime.Parse(reader.GetString(3)), 
                LocalPath = reader.GetString(4), IsArchived = reader.GetInt32(5) == 1 
            });
        }
        return projects;
    }

    public async Task UpdateProjectAsync(Project project)
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = "UPDATE Projects SET Name = $name, IsArchived = $arch WHERE Id = $id;";
        command.Parameters.AddWithValue("$name", project.Name);
        command.Parameters.AddWithValue("$arch", project.IsArchived ? 1 : 0);
        command.Parameters.AddWithValue("$id", project.Id.ToString());
        await command.ExecuteNonQueryAsync();
    }

    public async Task DeleteProjectAsync(Guid id)
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM Projects WHERE Id = $id;";
        command.Parameters.AddWithValue("$id", id.ToString());
        await command.ExecuteNonQueryAsync();
    }
}