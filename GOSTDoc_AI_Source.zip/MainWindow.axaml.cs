using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Platform.Storage;
using System.Linq;
using System.IO;
using System.Collections.Generic;

namespace GOSTDoc.Desktop;
public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);

    private void OnGostSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (sender is ListBox listBox && DataContext is MainWindowViewModel vm)
            vm.UpdateSelectedStandards(listBox.SelectedItems?.Cast<object>() ?? Enumerable.Empty<object>());
    }

    private void OnAuditGostSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (sender is ListBox listBox && DataContext is MainWindowViewModel vm)
            vm.UpdateAuditStandards(listBox.SelectedItems?.Cast<object>() ?? Enumerable.Empty<object>());
    }

    private async void OnChooseModelClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Выберите локальную модель GGUF",
            AllowMultiple = false,
            FileTypeFilter = new[] { new FilePickerFileType("Модель GGUF") { Patterns = new[] { "*.gguf" } } }
        });
        if (files.Count > 0 && DataContext is MainWindowViewModel vm)
            vm.ConfigureModelPath(files[0].Path.LocalPath);
    }

    private async void OnImportClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = "Документы", AllowMultiple = true });
        if (files.Any() && DataContext is MainWindowViewModel vm)
            await vm.ImportFilesAsync(files.Select(f => f.Path.LocalPath).ToArray());
    }

    private async void OnLoadAuditClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = "Документ на проверку", AllowMultiple = false });
        if (files.Any() && DataContext is MainWindowViewModel vm)
            await vm.LoadAuditFileAsync(files.First().Path.LocalPath);
    }

    private async void OnImportStandardDocClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { 
            Title = "Выберите файлы ГОСТов", AllowMultiple = true,
            FileTypeFilter = new[] { new FilePickerFileType("Документы") { Patterns = new[] { "*.pdf", "*.docx", "*.txt", "*.tiff", "*.tif" } } } 
        });
        if (files.Any() && DataContext is MainWindowViewModel vm)
        {
            foreach (var file in files) await vm.ImportStandardFromFileAsync(file.Path.LocalPath);
        }
    }

    private async void OnExportClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var file = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions { Title = "Сохранить", DefaultExtension = "docx" });
        if (file != null && DataContext is MainWindowViewModel vm)
            vm.ExportDocument(file.Path.LocalPath);
    }

    private async void OnExportAuditClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var file = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions { Title = "Сохранить проверенный документ", DefaultExtension = "docx" });
        if (file != null && DataContext is MainWindowViewModel vm)
            vm.ExportDocument(file.Path.LocalPath, vm.AuditText);
    }

    private async void OnExportProjectClick(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;
        var file = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions { Title = "Экспорт проекта", DefaultExtension = "json" });
        if (file != null && DataContext is MainWindowViewModel vm)
            vm.ExportProjectToJson(file.Path.LocalPath);
    }
}