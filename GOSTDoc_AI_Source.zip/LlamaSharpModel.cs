using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;
using GOSTDoc.Core;
using LLama;
using LLama.Common;
using LLama.Sampling;

namespace GOSTDoc.Infrastructure;

public class LlamaSharpModel : ILocalLanguageModel
{
    private readonly string _modelPath;
    private LLamaWeights? _weights;
    private ModelParams? _parameters;

    public LlamaSharpModel(string modelPath)
    {
        _modelPath = modelPath;
    }

    public async Task<string> GenerateAsync(string prompt)
    {
        if (!File.Exists(_modelPath))
            throw new FileNotFoundException("Локальная модель GGUF не найдена. Выберите файл модели в настройках приложения. Для работы не требуется подключение к интернету.", _modelPath);

        if (_weights == null)
        {
            // GpuLayerCount = 0 означает использование только CPU
            _parameters = new ModelParams(_modelPath) { ContextSize = 8192, GpuLayerCount = 0 };
            _weights = LLamaWeights.LoadFromFile(_parameters);
        }

        var executor = new StatelessExecutor(_weights, _parameters!);
        
        var inferenceParams = new InferenceParams
        {
            MaxTokens = 2048,
            AntiPrompts = new List<string> { "<|im_end|>", "<|im_start|>" },
            SamplingPipeline = new DefaultSamplingPipeline
            {
                Temperature = 0.2f,
                TopP = 0.9f,
                RepeatPenalty = 1.1f
            }
        };

        var result = "";
        await foreach (var text in executor.InferAsync(prompt, inferenceParams))
        {
            result += text;
        }
        
        return result.Trim();
    }
}