using Xunit;
using GOSTDoc.Infrastructure;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Data.Sqlite;

namespace GOSTDoc.Tests;
public class StandardRepositoryTests
{
    [Fact]
    public async Task CanImportStandardFromJson()
    {
        var tempDb = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"test_std_{System.Guid.NewGuid()}.db");
        var repo = new SqliteStandardRepository(tempDb);
        await repo.InitializeAsync();
        
        var json = @"{
            ""Code"": ""ГОСТ 19.505-79"",
            ""Title"": ""Руководство оператора"",
            ""Status"": ""Действует"",
            ""Rules"": [
                { ""SectionName"": ""Назначение программы"", ""IsMandatory"": true }
            ]
        }";

        await repo.ImportJsonPackAsync(json);
        var stds = await repo.GetAllStandardsAsync();
        
        Assert.Single(stds);
        Assert.Equal("ГОСТ 19.505-79", stds.First().Code);
        
        SqliteConnection.ClearAllPools();
        try { System.IO.File.Delete(tempDb); } catch { }
    }
}