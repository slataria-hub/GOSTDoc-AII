using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GOSTDoc.Core;
public interface ISourceDocumentRepository
{
    Task InitializeAsync();
    Task AddAsync(SourceDocument doc);
    Task<IEnumerable<SourceDocument>> GetByProjectIdAsync(Guid projectId);
}