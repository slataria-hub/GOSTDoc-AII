using System;
using GOSTDoc.Core;
using DocumentFormat.OpenXml.Packaging;

namespace GOSTDoc.Infrastructure;
public class DocxExtractor : ITextExtractor
{
    public bool CanExtract(string filePath) => filePath.EndsWith(".docx", StringComparison.OrdinalIgnoreCase);
    public string ExtractText(string filePath)
    {
        using var doc = WordprocessingDocument.Open(filePath, false);
        return doc.MainDocumentPart?.Document?.Body?.InnerText ?? string.Empty;
    }
}