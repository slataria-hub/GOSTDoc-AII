using System;
using System.IO;
using System.Text.Json;

namespace GOSTDoc.Desktop;

/// <summary>Настройки хранятся только на локальном компьютере. Сетевые службы не используются.</summary>
internal sealed class LocalAppSettings
{
    public string ModelPath { get; set; } = string.Empty;

    public static string SettingsPath
    {
        get
        {
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GOSTDocApp");
            Directory.CreateDirectory(folder);
            return Path.Combine(folder, "settings.json");
        }
    }

    public static LocalAppSettings Load()
    {
        try
        {
            if (File.Exists(SettingsPath))
                return JsonSerializer.Deserialize<LocalAppSettings>(File.ReadAllText(SettingsPath)) ?? new LocalAppSettings();
        }
        catch { /* Повреждённый файл настроек не должен мешать запуску приложения. */ }
        return new LocalAppSettings();
    }

    public void Save() => File.WriteAllText(SettingsPath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
}
