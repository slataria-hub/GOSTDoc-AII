using Xunit;
using GOSTDoc.Infrastructure;
using System.Threading.Tasks;
using System.Linq;

namespace GOSTDoc.Tests;
public class TextExtractorTests
{
    [Fact]
    public async Task CanExtractTxtAndSave()
    {
        var tempTxt = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"test_{System.Guid.NewGuid()}.txt");
        await System.IO.File.WriteAllTextAsync(tempTxt, "Тестовый текст ГОСТ");
        
        var extractor = new TxtExtractor();
        Assert.True(extractor.CanExtract(tempTxt));
        var text = extractor.ExtractText(tempTxt);
        Assert.Equal("Тестовый текст ГОСТ", text);

        System.IO.File.Delete(tempTxt);
    }
}