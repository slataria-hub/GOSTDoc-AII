using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using GOSTDoc.Core;
using GOSTDoc.Infrastructure;

namespace GOSTDoc.Desktop;
public class MainWindowViewModel : INotifyPropertyChanged
{
    private readonly IProjectRepository _projectRepo;
    private readonly ISourceDocumentRepository _docRepo;
    private readonly IStandardRepository _standardRepo;
    private readonly ITextExtractor[] _extractors;
    private DocumentGenerator _generator;
    private readonly IDocumentExporter _exporter;
    private ILocalLanguageModel _llm;

    public ObservableCollection<Project> Projects { get; } = new();
    public ObservableCollection<SourceDocument> Documents { get; } = new();
    public ObservableCollection<StandardEdition> Standards { get; } = new();
    public ObservableCollection<ValidationFinding> ValidationReport { get; } = new();
    public ObservableCollection<StandardEdition> SelectedStandards { get; } = new();
    
    public ObservableCollection<ProofreadingError> ProofreadingErrors { get; } = new();

    // Свойства для вкладки Аудит
    public ObservableCollection<StandardEdition> AuditStandards { get; } = new();
    public ObservableCollection<ProofreadingError> AuditErrors { get; } = new();
    
    private string _auditText = "Загрузите документ или вставьте текст сюда для проверки...";
    public string AuditText
    {
        get => _auditText;
        set { _auditText = value; OnPropertyChanged(); }
    }

    public ICommand CreateProjectCommand { get; }
    public string ModelPath { get; private set; } = string.Empty;
    private string _modelStatus = "Модель не выбрана";
    public string ModelStatus { get => _modelStatus; private set { _modelStatus = value; OnPropertyChanged(); } }
    public ICommand GenerateDocumentCommand { get; }
    public ICommand RefineDocumentCommand { get; }
    public ICommand ProofreadCommand { get; }
    public ICommand ApplyCorrectionCommand { get; }
    
    public ICommand StartRenameCommand { get; }
    public ICommand SaveRenameCommand { get; }
    public ICommand CancelRenameCommand { get; }
    public ICommand DeleteProjectCommand { get; }
    public ICommand ArchiveProjectCommand { get; }
    public ICommand DeleteGostCommand { get; }

    // Команды Аудита
    public ICommand ProofreadAuditCommand { get; }
    public ICommand HumanizeCommand { get; }
    public ICommand HumanizeAuditCommand { get; }
    public ICommand ApplyAuditCorrectionCommand { get; }

    private Project? _selectedProject;
    public Project? SelectedProject
    {
        get => _selectedProject;
        set { _selectedProject = value; OnPropertyChanged(); IsRenaming = false; _ = LoadDocumentsAsync(); }
    }

    private StandardEdition? _selectedGost;
    public StandardEdition? SelectedGost
    {
        get => _selectedGost;
        set { _selectedGost = value; OnPropertyChanged(); }
    }

    private bool _isRenaming;
    public bool IsRenaming
    {
        get => _isRenaming;
        set { _isRenaming = value; OnPropertyChanged(); }
    }

    private string _editProjectName = "";
    public string EditProjectName
    {
        get => _editProjectName;
        set { _editProjectName = value; OnPropertyChanged(); }
    }

    private string _userPrompt = "Создай руководство оператора. Нарисуй структурную схему.";
    public string UserPrompt
    {
        get => _userPrompt;
        set { _userPrompt = value; OnPropertyChanged(); }
    }

    private string _refinePrompt = "";
    public string RefinePrompt
    {
        get => _refinePrompt;
        set { _refinePrompt = value; OnPropertyChanged(); }
    }

    private string _generatedDocumentText = "Здесь появится готовый документ...";
    public string GeneratedDocumentText
    {
        get => _generatedDocumentText;
        set { _generatedDocumentText = value; OnPropertyChanged(); }
    }

    private bool _isGenerating;
    public bool IsGenerating
    {
        get => _isGenerating;
        set { _isGenerating = value; OnPropertyChanged(); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public MainWindowViewModel()
    {
        var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var appFolder = Path.Combine(appData, "GOSTDocApp");
        Directory.CreateDirectory(appFolder);
        var dbPath = Path.Combine(appFolder, "gostdoc.db");

        _projectRepo = new SqliteProjectRepository(dbPath);
        _docRepo = new SqliteSourceDocumentRepository(dbPath);
        _standardRepo = new SqliteStandardRepository(dbPath);
        _extractors = new ITextExtractor[] { new TxtExtractor(), new PdfExtractor(), new DocxExtractor(), new TiffExtractor() };
        
        var settings = LocalAppSettings.Load();
        ModelPath = ResolveModelPath(settings.ModelPath);
        _llm = new LlamaSharpModel(ModelPath);
        _generator = new DocumentGenerator(_llm, new NormControlEngine());
        RefreshModelStatus();
        _exporter = new DocxExporter();

        CreateProjectCommand = new RelayCommand(_ => { _ = CreateProjectAsync(); });
        GenerateDocumentCommand = new RelayCommand(async _ => await GenerateDocumentAsync());
        RefineDocumentCommand = new RelayCommand(async _ => await RefineDocumentAsync());
        ProofreadCommand = new RelayCommand(async _ => await ProofreadGeneratedAsync());
        ApplyCorrectionCommand = new RelayCommand(obj => ApplyCorrection(obj));
        
        ProofreadAuditCommand = new RelayCommand(async _ => await ProofreadAuditAsync());
        HumanizeCommand = new RelayCommand(async _ => await HumanizeGeneratedAsync());
        HumanizeAuditCommand = new RelayCommand(async _ => await HumanizeAuditAsync());
        ApplyAuditCorrectionCommand = new RelayCommand(obj => ApplyAuditCorrection(obj));
        
        StartRenameCommand = new RelayCommand(_ => StartRename());
        SaveRenameCommand = new RelayCommand(async _ => await SaveRenameAsync());
        CancelRenameCommand = new RelayCommand(_ => IsRenaming = false);
        DeleteProjectCommand = new RelayCommand(_ => { _ = DeleteProjectAsync(); });
        ArchiveProjectCommand = new RelayCommand(_ => { _ = ArchiveProjectAsync(); });
        DeleteGostCommand = new RelayCommand(_ => { _ = DeleteGostAsync(); });
        
        _ = LoadAllAsync();
    }

    public void ConfigureModelPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        ModelPath = Path.GetFullPath(path);
        var settings = LocalAppSettings.Load();
        settings.ModelPath = ModelPath;
        settings.Save();
        // Модель загружается лениво при первом запросе. При смене пути создаём новый локальный адаптер.
        _llm = new LlamaSharpModel(ModelPath);
        _generator = new DocumentGenerator(_llm, new NormControlEngine());
        RefreshModelStatus();
        OnPropertyChanged(nameof(ModelPath));
    }

    private void RefreshModelStatus()
    {
        ModelStatus = !string.IsNullOrWhiteSpace(ModelPath) && File.Exists(ModelPath)
            ? $"Готова к запуску\n{Path.GetFileName(ModelPath)}"
            : "Файл модели не найден. Выберите GGUF-файл.";
    }

    private static string ResolveModelPath(string configuredPath)
    {
        if (!string.IsNullOrWhiteSpace(configuredPath) && File.Exists(configuredPath)) return configuredPath;
        var fileName = "Qwen2.5-7B-Instruct-Q4_K_M.gguf";
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Models", fileName),
            Path.Combine(AppContext.BaseDirectory, fileName),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GOSTDocApp", "Models", fileName),
            @"C:\GOSTDoc\Models\Qwen2.5-7B-Instruct-Q4_K_M.gguf"
        };
        return candidates.FirstOrDefault(File.Exists) ?? candidates[0];
    }

    private async Task LoadAllAsync()
    {
        await _projectRepo.InitializeAsync();
        await _docRepo.InitializeAsync();
        await _standardRepo.InitializeAsync();
        await LoadProjectsAsync();
        await LoadStandardsAsync();
    }

    private async Task LoadProjectsAsync()
    {
        var projs = await _projectRepo.GetAllProjectsAsync();
        Projects.Clear();
        foreach(var p in projs) Projects.Add(p);
    }

    private async Task LoadStandardsAsync()
    {
        var stds = await _standardRepo.GetAllStandardsAsync();
        Standards.Clear();
        foreach (var s in stds) Standards.Add(s);
    }

    public void UpdateSelectedStandards(IEnumerable<object> selectedItems)
    {
        SelectedStandards.Clear();
        foreach (var item in selectedItems)
            if (item is StandardEdition std) SelectedStandards.Add(std);
    }

    public void UpdateAuditStandards(IEnumerable<object> selectedItems)
    {
        AuditStandards.Clear();
        foreach (var item in selectedItems)
            if (item is StandardEdition std) AuditStandards.Add(std);
    }

    private async Task LoadDocumentsAsync()
    {
        Documents.Clear();
        if (SelectedProject == null) return;
        var docs = await _docRepo.GetByProjectIdAsync(SelectedProject.Id);
        foreach(var d in docs) Documents.Add(d);
    }

    private async Task CreateProjectAsync()
    {
        var newProj = await _projectRepo.CreateProjectAsync($"Проект от {DateTime.Now:HH:mm:ss}", "Новый", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GOSTDocApp", "Projects", Guid.NewGuid().ToString("N")));
        Projects.Add(newProj);
        SelectedProject = newProj;
    }

    private void StartRename()
    {
        if (SelectedProject == null) return;
        EditProjectName = SelectedProject.Name;
        IsRenaming = true;
    }

    private async Task SaveRenameAsync()
    {
        if (SelectedProject == null || string.IsNullOrWhiteSpace(EditProjectName)) return;
        SelectedProject.Name = EditProjectName;
        await _projectRepo.UpdateProjectAsync(SelectedProject);
        var index = Projects.IndexOf(SelectedProject);
        if (index >= 0) Projects[index] = SelectedProject; 
        IsRenaming = false;
    }

    private async Task DeleteProjectAsync()
    {
        if (SelectedProject == null) return;
        await _projectRepo.DeleteProjectAsync(SelectedProject.Id);
        Projects.Remove(SelectedProject);
        SelectedProject = null;
    }

    private async Task ArchiveProjectAsync()
    {
        if (SelectedProject == null) return;
        SelectedProject.IsArchived = !SelectedProject.IsArchived;
        await _projectRepo.UpdateProjectAsync(SelectedProject);
        var index = Projects.IndexOf(SelectedProject);
        if (index >= 0) Projects[index] = SelectedProject;
    }

    private async Task DeleteGostAsync()
    {
        if (SelectedGost == null) return;
        await _standardRepo.DeleteStandardAsync(SelectedGost.Id);
        await LoadStandardsAsync();
        SelectedGost = null;
    }

    private async Task GenerateDocumentAsync()
    {
        if (SelectedProject == null || !SelectedStandards.Any())
        {
            GeneratedDocumentText = "ОШИБКА: Выберите проект и ГОСТ!";
            return;
        }

        IsGenerating = true;
        GeneratedDocumentText = "Генерация...";
        ValidationReport.Clear();
        ProofreadingErrors.Clear();

        try
        {
            var result = await Task.Run(() => _generator.GenerateAsync(SelectedStandards, Documents, UserPrompt));
            GeneratedDocumentText = result.GeneratedText;
            foreach (var finding in result.Findings) ValidationReport.Add(finding);
        }
        catch (Exception ex) { GeneratedDocumentText = $"ОШИБКА: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    private async Task ProofreadGeneratedAsync()
    {
        if (string.IsNullOrWhiteSpace(GeneratedDocumentText)) return;
        IsGenerating = true;
        ProofreadingErrors.Clear();
        
        try
        {
            var errors = await Task.Run(() => _generator.ProofreadAsync(GeneratedDocumentText, SelectedStandards));
            foreach (var err in errors) ProofreadingErrors.Add(err);
        }
        catch (Exception ex) { ProofreadingErrors.Add(new ProofreadingError { Original = "Системная ошибка", Suggestion = ex.Message, Reason = "Сбой при проверке" }); }
        finally { IsGenerating = false; }
    }

    private void ApplyCorrection(object? errorObj)
    {
        if (errorObj is ProofreadingError error && !string.IsNullOrWhiteSpace(error.Original))
        {
            if (GeneratedDocumentText.Contains(error.Original))
            {
                GeneratedDocumentText = GeneratedDocumentText.Replace(error.Original, error.Suggestion);
                ProofreadingErrors.Remove(error);
            }
        }
    }

    private async Task RefineDocumentAsync()
    {
        if (string.IsNullOrWhiteSpace(RefinePrompt) || string.IsNullOrWhiteSpace(GeneratedDocumentText)) return;
        IsGenerating = true;
        var oldText = GeneratedDocumentText;
        GeneratedDocumentText = "Нейросеть вносит правки...";

        try
        {
            var refined = await Task.Run(() => _generator.RefineAsync(oldText, RefinePrompt));
            GeneratedDocumentText = refined;
            RefinePrompt = ""; 
        }
        catch (Exception ex) { GeneratedDocumentText = $"ОШИБКА: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    // --- Логика Аудита ---

    public async Task LoadAuditFileAsync(string filePath)
    {
        var extractor = _extractors.FirstOrDefault(x => x.CanExtract(filePath));
        if (extractor == null)
        {
            AuditText = "Формат файла не поддерживается.";
            return;
        }

        try
        {
            var text = await Task.Run(() => extractor.ExtractText(filePath));
            AuditText = text;
            AuditErrors.Clear();
        }
        catch (Exception ex)
        {
            AuditText = $"Ошибка чтения файла: {ex.Message}";
        }
    }

    private async Task HumanizeGeneratedAsync()
    {
        if (string.IsNullOrWhiteSpace(GeneratedDocumentText)) return;
        IsGenerating = true;
        var oldText = GeneratedDocumentText;
        GeneratedDocumentText = "Нейросеть переписывает текст (делает его человечным)...";

        try
        {
            var humanized = await Task.Run(() => _generator.HumanizeAsync(oldText));
            GeneratedDocumentText = humanized;
        }
        catch (Exception ex) { GeneratedDocumentText = $"ОШИБКА: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    private async Task HumanizeAuditAsync()
    {
        if (string.IsNullOrWhiteSpace(AuditText)) return;
        IsGenerating = true;
        var oldText = AuditText;
        AuditText = "Нейросеть переписывает текст...";

        try
        {
            var humanized = await Task.Run(() => _generator.HumanizeAsync(oldText));
            AuditText = humanized;
        }
        catch (Exception ex) { AuditText = $"ОШИБКА: {ex.Message}"; }
        finally { IsGenerating = false; }
    }
    private async Task ProofreadAuditAsync()
    {
        if (string.IsNullOrWhiteSpace(AuditText)) return;
        IsGenerating = true;
        AuditErrors.Clear();

        try
        {
            var errors = await Task.Run(() => _generator.ProofreadAsync(AuditText, AuditStandards));
            foreach (var err in errors) AuditErrors.Add(err);
        }
        catch (Exception ex) { AuditErrors.Add(new ProofreadingError { Original = "Системная ошибка", Suggestion = ex.Message, Reason = "Сбой при проверке" }); }
        finally { IsGenerating = false; }
    }

    private void ApplyAuditCorrection(object? errorObj)
    {
        if (errorObj is ProofreadingError error && !string.IsNullOrWhiteSpace(error.Original))
        {
            if (AuditText.Contains(error.Original))
            {
                AuditText = AuditText.Replace(error.Original, error.Suggestion);
                AuditErrors.Remove(error);
            }
        }
    }

    public void ExportProjectToJson(string filePath)
    {
        if (SelectedProject == null) return;
        var data = new { Project = SelectedProject, Documents = Documents, GeneratedText = GeneratedDocumentText };
        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
        File.WriteAllText(filePath, json);
    }

    public void ExportDocument(string filePath, string customText = null) => _exporter.ExportToDocx(customText ?? GeneratedDocumentText, filePath);

    public async Task ImportFilesAsync(string[] filePaths)
    {
        if (SelectedProject == null) return;
        foreach (var path in filePaths)
        {
            var extractor = _extractors.FirstOrDefault(x => x.CanExtract(path));
            if (extractor == null) continue;

            try
            {
                var hash = CalculateSha256(path);
                var text = await Task.Run(() => extractor.ExtractText(path));
                var doc = new SourceDocument { ProjectId = SelectedProject.Id, FileName = Path.GetFileName(path), FileHash = hash, ExtractedText = text, Status = "Извлечено" };
                await _docRepo.AddAsync(doc);
                Documents.Add(doc);
            }
            catch (Exception ex) { Documents.Add(new SourceDocument { FileName = Path.GetFileName(path), Status = "Ошибка", ExtractedText = ex.Message, ProjectId = SelectedProject.Id }); }
        }
    }

    public async Task ImportStandardFromFileAsync(string filePath)
    {
        var extractor = _extractors.FirstOrDefault(x => x.CanExtract(filePath));
        if (extractor == null) 
        {
            GeneratedDocumentText += $"\nФормат {Path.GetExtension(filePath)} не поддерживается.";
            return;
        }

        GeneratedDocumentText += $"\nЧтение {Path.GetFileName(filePath)}...";

        try
        {
            var text = await Task.Run(() => extractor.ExtractText(filePath));
            if (string.IsNullOrWhiteSpace(text) || text.StartsWith("Ошибка"))
            {
                GeneratedDocumentText += $"\nНе удалось извлечь текст из {Path.GetFileName(filePath)}";
                return;
            }

            var snippet = text.Length > 15000 ? text.Substring(0, 15000) : text;

            GeneratedDocumentText += $"\nИИ анализирует {Path.GetFileName(filePath)} (это может занять около минуты)...";
            
            var prompt = $"<|im_start|>system\nТы  эксперт по ГОСТ. Твоя задача  проанализировать текст стандарта и извлечь обязательные разделы и правила оформления. Верни ответ СТРОГО в формате JSON (без markdown-разметки и без ```json):\n{{\n  \"Code\": \"Номер ГОСТа\",\n  \"Title\": \"Название\",\n  \"Rules\": [\n    {{ \"SectionName\": \"Раздел\", \"IsMandatory\": true, \"Category\": \"Structure\", \"RuleText\": \"\" }},\n    {{ \"SectionName\": \"Текст\", \"IsMandatory\": false, \"Category\": \"Text\", \"RuleText\": \"Правило\" }}\n  ]\n}}\n<|im_end|>\n<|im_start|>user\nТекст стандарта:\n{snippet}<|im_end|>\n<|im_start|>assistant\n";
            
            var aiResponse = await _llm.GenerateAsync(prompt);
            
            aiResponse = aiResponse.Replace("```json", "").Replace("```", "").Trim();
            var startIdx = aiResponse.IndexOf('{');
            var endIdx = aiResponse.LastIndexOf('}');
            if (startIdx >= 0 && endIdx > startIdx) aiResponse = aiResponse.Substring(startIdx, endIdx - startIdx + 1);

            var newStandard = System.Text.Json.JsonSerializer.Deserialize<StandardEdition>(aiResponse, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            
            if (newStandard != null && newStandard.Rules.Count > 0)
            {
                newStandard.Id = Guid.NewGuid();
                foreach(var r in newStandard.Rules) r.StandardEditionId = newStandard.Id;
                
                if (string.IsNullOrWhiteSpace(newStandard.Code) || newStandard.Code == "Номер ГОСТа")
                    newStandard.Code = Path.GetFileNameWithoutExtension(filePath);

                var json = System.Text.Json.JsonSerializer.Serialize(newStandard);
                await _standardRepo.ImportJsonPackAsync(json);
                await LoadStandardsAsync();
                
                GeneratedDocumentText += $"\nУспешно добавлен: {newStandard.Code} ({newStandard.Rules.Count} правил)";
            }
            else
            {
                GeneratedDocumentText += $"\nИИ не смог распознать правила в {Path.GetFileName(filePath)}";
            }
        }
        catch (Exception ex)
        {
            GeneratedDocumentText += $"\nОШИБКА {Path.GetFileName(filePath)}: {ex.Message}";
        }
    }

    private string CalculateSha256(string filePath)
    {
        using var stream = File.OpenRead(filePath);
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(stream));
    }

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

public class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    public RelayCommand(Action<object?> execute) => _execute = execute;
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => true; 
    public void Execute(object? parameter) => _execute(parameter);
}