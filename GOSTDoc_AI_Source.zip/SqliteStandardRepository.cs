using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using GOSTDoc.Core;

namespace GOSTDoc.Infrastructure;

public class SqliteStandardRepository : IStandardRepository
{
    private readonly string _connectionString;
    public SqliteStandardRepository(string dbPath) => _connectionString = $"Data Source={dbPath}";

    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        var command = connection.CreateCommand();
        command.CommandText = @"
            CREATE TABLE IF NOT EXISTS StandardEditions (Id TEXT PRIMARY KEY, Code TEXT NOT NULL, Title TEXT NOT NULL, Status TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS NormativeRules (
                Id TEXT PRIMARY KEY,
                StandardEditionId TEXT NOT NULL,
                SectionName TEXT NOT NULL,
                IsMandatory INTEGER NOT NULL,
                Category TEXT NOT NULL DEFAULT 'Structure',
                RuleText TEXT NOT NULL DEFAULT ''
            );";
        await command.ExecuteNonQueryAsync();
    }

    public async Task<IEnumerable<StandardEdition>> GetAllStandardsAsync()
    {
        var standards = new List<StandardEdition>();
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        
        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT Id, Code, Title, Status FROM StandardEditions;";
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var std = new StandardEdition
            {
                Id = Guid.Parse(reader.GetString(0)), Code = reader.GetString(1), Title = reader.GetString(2), Status = reader.GetString(3)
            };
            
            var ruleCmd = connection.CreateCommand();
            ruleCmd.CommandText = "SELECT SectionName, IsMandatory, Category, RuleText FROM NormativeRules WHERE StandardEditionId = $id;";
            ruleCmd.Parameters.AddWithValue("$id", std.Id.ToString());
            using var ruleReader = await ruleCmd.ExecuteReaderAsync();
            while (await ruleReader.ReadAsync())
            {
                std.Rules.Add(new NormativeRule
                {
                    StandardEditionId = std.Id,
                    SectionName = ruleReader.GetString(0),
                    IsMandatory = ruleReader.GetInt32(1) == 1,
                    Category = ruleReader.IsDBNull(2) ? "Structure" : ruleReader.GetString(2),
                    RuleText = ruleReader.IsDBNull(3) ? "" : ruleReader.GetString(3)
                });
            }
            standards.Add(std);
        }
        return standards;
    }

    public async Task ImportJsonPackAsync(string jsonContent)
    {
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        var newStandard = JsonSerializer.Deserialize<StandardEdition>(jsonContent, options);
        if (newStandard == null) throw new Exception("Неверный формат JSON");

        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();

        try
        {
            var checkCmd = connection.CreateCommand();
            checkCmd.Transaction = transaction;
            checkCmd.CommandText = "SELECT COUNT(*) FROM StandardEditions WHERE Code = $code;";
            checkCmd.Parameters.AddWithValue("$code", newStandard.Code);
            if (Convert.ToInt32(await checkCmd.ExecuteScalarAsync()) > 0) throw new Exception($"Стандарт {newStandard.Code} уже существует.");

            var cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            cmd.CommandText = "INSERT INTO StandardEditions (Id, Code, Title, Status) VALUES ($id, $code, $title, $status);";
            cmd.Parameters.AddWithValue("$id", newStandard.Id.ToString());
            cmd.Parameters.AddWithValue("$code", newStandard.Code);
            cmd.Parameters.AddWithValue("$title", newStandard.Title);
            cmd.Parameters.AddWithValue("$status", newStandard.Status);
            await cmd.ExecuteNonQueryAsync();

            foreach (var rule in newStandard.Rules)
            {
                var ruleCmd = connection.CreateCommand();
                ruleCmd.Transaction = transaction;
                ruleCmd.CommandText = "INSERT INTO NormativeRules (Id, StandardEditionId, SectionName, IsMandatory, Category, RuleText) VALUES ($id, $stdId, $sec, $mand, $cat, $text);";
                ruleCmd.Parameters.AddWithValue("$id", Guid.NewGuid().ToString());
                ruleCmd.Parameters.AddWithValue("$stdId", newStandard.Id.ToString());
                ruleCmd.Parameters.AddWithValue("$sec", rule.SectionName);
                ruleCmd.Parameters.AddWithValue("$mand", rule.IsMandatory ? 1 : 0);
                ruleCmd.Parameters.AddWithValue("$cat", rule.Category ?? "Structure");
                ruleCmd.Parameters.AddWithValue("$text", rule.RuleText ?? "");
                await ruleCmd.ExecuteNonQueryAsync();
            }
            await transaction.CommitAsync();
        }
        catch { await transaction.RollbackAsync(); throw; }
    }

    public async Task DeleteStandardAsync(Guid id)
    {
        using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();
        
        try
        {
            // Сначала удаляем правила
            var ruleCmd = connection.CreateCommand();
            ruleCmd.Transaction = transaction;
            ruleCmd.CommandText = "DELETE FROM NormativeRules WHERE StandardEditionId = $id;";
            ruleCmd.Parameters.AddWithValue("$id", id.ToString());
            await ruleCmd.ExecuteNonQueryAsync();

            // Затем сам стандарт
            var stdCmd = connection.CreateCommand();
            stdCmd.Transaction = transaction;
            stdCmd.CommandText = "DELETE FROM StandardEditions WHERE Id = $id;";
            stdCmd.Parameters.AddWithValue("$id", id.ToString());
            await stdCmd.ExecuteNonQueryAsync();

            await transaction.CommitAsync();
        }
        catch { await transaction.RollbackAsync(); throw; }
    }
}