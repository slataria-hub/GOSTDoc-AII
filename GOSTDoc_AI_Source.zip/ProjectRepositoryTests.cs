using Xunit;
using GOSTDoc.Infrastructure;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Data.Sqlite;

namespace GOSTDoc.Tests;
public class ProjectRepositoryTests
{
    [Fact]
    public async Task CanCreateAndRetrieveProject()
    {
        var tempDb = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"test_{System.Guid.NewGuid()}.db");
        var repo = new SqliteProjectRepository(tempDb);
        
        await repo.InitializeAsync();
        await repo.CreateProjectAsync("Тестовый проект", "Описание", "C:\\Projects\\Test");
        var projects = await repo.GetAllProjectsAsync();
        
        Assert.Single(projects);
        Assert.Equal("Тестовый проект", projects.First().Name);
        
        // Очищаем пул соединений, чтобы файл разблокировался
        SqliteConnection.ClearAllPools();
        
        // Пытаемся удалить, если не получается - игнорируем (временный файл)
        try { System.IO.File.Delete(tempDb); } catch { }
    }
}