using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace GOSTDoc.Core;

public class ValidationFinding
{
    public string RuleName { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public bool IsPassed { get; set; }
}

public class GenerationResult
{
    public string GeneratedText { get; set; } = string.Empty;
    public List<ValidationFinding> Findings { get; set; } = new();
}

// Новая модель для проверки ошибок
public class ProofreadingError
{
    [JsonPropertyName("original")]
    public string Original { get; set; } = string.Empty;
    
    [JsonPropertyName("suggestion")]
    public string Suggestion { get; set; } = string.Empty;
    
    [JsonPropertyName("reason")]
    public string Reason { get; set; } = string.Empty;
}