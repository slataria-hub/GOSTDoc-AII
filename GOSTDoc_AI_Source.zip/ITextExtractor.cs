namespace GOSTDoc.Core;
public interface ITextExtractor
{
    bool CanExtract(string filePath);
    string ExtractText(string filePath);
}