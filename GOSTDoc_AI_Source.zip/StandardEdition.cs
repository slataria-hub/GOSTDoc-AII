using System;
using System.Collections.Generic;

namespace GOSTDoc.Core;

public class StandardEdition
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public List<NormativeRule> Rules { get; set; } = new();
}

public class NormativeRule
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StandardEditionId { get; set; }
    public string SectionName { get; set; } = string.Empty;
    public bool IsMandatory { get; set; }
    
    // НОВЫЕ ПОЛЯ для текстовых требований (ГОСТ Р 2.105)
    public string Category { get; set; } = "Structure"; // Structure, Text, Format
    public string RuleText { get; set; } = string.Empty; // Текстовое описание требования
}