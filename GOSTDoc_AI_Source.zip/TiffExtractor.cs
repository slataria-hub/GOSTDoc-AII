using System;
using GOSTDoc.Core;
using Tesseract;

namespace GOSTDoc.Infrastructure;
public class TiffExtractor : ITextExtractor
{
    public bool CanExtract(string filePath) => 
        filePath.EndsWith(".tiff", StringComparison.OrdinalIgnoreCase) || 
        filePath.EndsWith(".tif", StringComparison.OrdinalIgnoreCase);
    
    public string ExtractText(string filePath)
    {
        var tessDataPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tessdata");
        if (!System.IO.Directory.Exists(tessDataPath))
        {
            return "ОШИБКА: Для распознавания TIFF требуется папка tessdata с файлом rus.traineddata в директории программы.";
        }

        try
        {
            using var engine = new TesseractEngine(tessDataPath, "rus", EngineMode.Default);
            using var img = Pix.LoadFromFile(filePath);
            using var page = engine.Process(img);
            return page.GetText();
        }
        catch (Exception ex)
        {
            return $"Ошибка OCR: {ex.Message}";
        }
    }
}