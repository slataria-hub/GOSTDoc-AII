using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace GOSTDoc.Core;
public interface IProjectRepository
{
    Task InitializeAsync();
    Task<Project> CreateProjectAsync(string name, string description, string path);
    Task<IEnumerable<Project>> GetAllProjectsAsync();
    Task UpdateProjectAsync(Project project);
    Task DeleteProjectAsync(Guid id);
}