using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GOSTDoc.Core;

public interface IStandardRepository
{
    Task InitializeAsync();
    Task<IEnumerable<StandardEdition>> GetAllStandardsAsync();
    Task ImportJsonPackAsync(string jsonContent);
    Task DeleteStandardAsync(Guid id);
}