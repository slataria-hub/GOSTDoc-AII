using System;
namespace GOSTDoc.Core;
public class Project
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public string LocalPath { get; set; } = string.Empty;
    public bool IsArchived { get; set; } = false;
}