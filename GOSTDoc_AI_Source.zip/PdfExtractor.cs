using System;
using System.Text;
using GOSTDoc.Core;
using UglyToad.PdfPig;

namespace GOSTDoc.Infrastructure;
public class PdfExtractor : ITextExtractor
{
    public bool CanExtract(string filePath) => filePath.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase);
    public string ExtractText(string filePath)
    {
        using var document = PdfDocument.Open(filePath);
        var text = new StringBuilder();
        foreach (var page in document.GetPages())
        {
            text.AppendLine(page.Text);
        }
        return text.ToString();
    }
}