using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GOSTDoc.Core;
using GOSTDoc.Infrastructure;
using Microsoft.Data.Sqlite;
using Xunit;

namespace GOSTDoc.Tests;

public class SourceDocumentRepositoryTests
{
    [Fact]
    public async Task CanAddRetrieveAndDeleteDocumentsByProject()
    {
        var tempDb = Path.Combine(Path.GetTempPath(), $"test_docs_{Guid.NewGuid():N}.db");
        var projects = new SqliteProjectRepository(tempDb);
        var docs = new SqliteSourceDocumentRepository(tempDb);
        await projects.InitializeAsync();
        await docs.InitializeAsync();

        var project = await projects.CreateProjectAsync("Проект", "", tempDb);
        var doc = new SourceDocument
        {
            ProjectId = project.Id,
            FileName = "source.txt",
            FileHash = "abc",
            Status = "Извлечено",
            ExtractedText = "Тестовый текст"
        };
        await docs.AddAsync(doc);
        Assert.Single(await docs.GetByProjectIdAsync(project.Id));

        await docs.DeleteByProjectIdAsync(project.Id);
        Assert.Empty(await docs.GetByProjectIdAsync(project.Id));

        SqliteConnection.ClearAllPools();
        try { File.Delete(tempDb); } catch { }
    }
}
