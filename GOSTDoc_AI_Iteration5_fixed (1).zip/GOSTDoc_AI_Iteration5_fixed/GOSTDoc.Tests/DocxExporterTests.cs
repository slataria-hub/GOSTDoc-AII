using System;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using GOSTDoc.Infrastructure;
using Xunit;

namespace GOSTDoc.Tests;

public class DocxExporterTests
{
    [Fact]
    public void ExportsDocumentWithParagraphsAndSectionProperties()
    {
        var file = Path.Combine(Path.GetTempPath(), $"gostdoc_{Guid.NewGuid():N}.docx");
        try
        {
            new DocxExporter().ExportToDocx("## Заголовок\n\nТекст документа", file);
            Assert.True(File.Exists(file));
            using var document = WordprocessingDocument.Open(file, false);
            var body = document.MainDocumentPart?.Document?.Body;
            Assert.NotNull(body);
            Assert.Equal("ЗаголовокТекст документа", body!.InnerText);
            Assert.NotNull(body.GetFirstChild<DocumentFormat.OpenXml.Wordprocessing.SectionProperties>());
        }
        finally { try { File.Delete(file); } catch { } }
    }
}
