using System;
using System.Collections.Generic;
using System.Linq;
using GOSTDoc.Core;
using GOSTDoc.Infrastructure;
using Xunit;

namespace GOSTDoc.Tests;

public class NormControlEngineTests
{
    [Fact]
    public void ReportsMissingAndPresentMandatorySections()
    {
        var standard = new StandardEdition
        {
            Code = "TEST-1",
            Rules = new List<NormativeRule>
            {
                new() { SectionName = "Назначение программы", IsMandatory = true, Category = "Structure" },
                new() { SectionName = "Условия выполнения", IsMandatory = true, Category = "Structure" },
                new() { SectionName = "Необязательное правило", IsMandatory = false, Category = "Structure" }
            }
        };

        var findings = new NormControlEngine().ValidateDocument("## Назначение программы", new[] { standard });

        Assert.Equal(2, findings.Count);
        Assert.Contains(findings, f => f.RuleName == "Назначение программы" && f.IsPassed);
        Assert.Contains(findings, f => f.RuleName == "Условия выполнения" && !f.IsPassed);
    }

    [Fact]
    public void ExplainsWhenNoStructuralRulesExist()
    {
        var standard = new StandardEdition
        {
            Code = "TEST-2",
            Rules = new List<NormativeRule> { new() { SectionName = "Текст", Category = "Text", RuleText = "Пиши ясно" } }
        };
        var findings = new NormControlEngine().ValidateDocument("Текст документа", new[] { standard });
        Assert.Single(findings);
        Assert.False(findings[0].IsPassed);
        Assert.Contains("не найдены", findings[0].Message.ToLowerInvariant());
    }
}
