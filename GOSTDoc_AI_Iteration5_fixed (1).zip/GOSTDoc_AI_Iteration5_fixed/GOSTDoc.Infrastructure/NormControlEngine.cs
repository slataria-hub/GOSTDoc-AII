using System;
using System.Collections.Generic;
using System.Linq;
using GOSTDoc.Core;

namespace GOSTDoc.Infrastructure;

public class NormControlEngine
{
    public List<ValidationFinding> ValidateDocument(string documentText, IEnumerable<StandardEdition> standards)
    {
        var findings = new List<ValidationFinding>();
        
        var allRules = standards
            .SelectMany(s => s.Rules)
            .Where(r => r.IsMandatory && r.Category == "Structure")
            .GroupBy(r => r.SectionName)
            .Select(g => g.First())
            .ToList();

        if (!allRules.Any())
        {
            findings.Add(new ValidationFinding
            {
                RuleName = "Внимание!",
                IsPassed = false,
                Message = "В выбранных ГОСТах не найдены обязательные требования к структуре разделов. Проверьте состав правил или импортируйте стандарт с требованиями к структуре."
            });
            return findings;
        }
        
        foreach (var rule in allRules)
        {
            bool exists = documentText.Contains(rule.SectionName, StringComparison.OrdinalIgnoreCase);
            
            findings.Add(new ValidationFinding
            {
                RuleName = rule.SectionName,
                IsPassed = exists,
                Message = exists ? "Обязательный раздел найден." : "ОТСУТСТВУЕТ обязательный раздел!"
            });
        }
        return findings;
    }
}