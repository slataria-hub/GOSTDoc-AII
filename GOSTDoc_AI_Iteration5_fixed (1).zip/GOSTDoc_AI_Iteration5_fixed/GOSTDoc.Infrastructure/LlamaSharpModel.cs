using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;
using GOSTDoc.Core;
using LLama;
using LLama.Common;
using LLama.Sampling;

namespace GOSTDoc.Infrastructure;

public class LlamaSharpModel : ILocalLanguageModel
{
    private readonly string _modelPath;
    private LLamaWeights? _weights;
    private ModelParams? _parameters;
    private readonly System.Threading.SemaphoreSlim _inferenceLock = new(1, 1);

    public LlamaSharpModel(string modelPath)
    {
        _modelPath = modelPath;
    }

    public async Task<string> GenerateAsync(string prompt)
    {
        if (!File.Exists(_modelPath))
            throw new FileNotFoundException("Локальная модель GGUF не найдена. Выберите файл модели в настройках приложения. Для работы не требуется подключение к интернету.", _modelPath);

        await _inferenceLock.WaitAsync();
        try
        {
            if (_weights == null)
            {
                // CPU-only backend: не требуется интернет или GPU.
                _parameters = new ModelParams(_modelPath) { ContextSize = 8192, GpuLayerCount = 0 };
                _weights = LLamaWeights.LoadFromFile(_parameters);
            }

            var executor = new StatelessExecutor(_weights, _parameters!);
            var inferenceParams = new InferenceParams
            {
                MaxTokens = 2048,
                AntiPrompts = new List<string> { "<|im_end|>", "<|im_start|>" },
                SamplingPipeline = new DefaultSamplingPipeline
                {
                    Temperature = 0.2f,
                    TopP = 0.9f,
                    RepeatPenalty = 1.1f
                }
            };

            var result = new System.Text.StringBuilder();
            await foreach (var text in executor.InferAsync(prompt, inferenceParams))
                result.Append(text);
            return result.ToString().Trim();
        }
        finally
        {
            _inferenceLock.Release();
        }
    }
}