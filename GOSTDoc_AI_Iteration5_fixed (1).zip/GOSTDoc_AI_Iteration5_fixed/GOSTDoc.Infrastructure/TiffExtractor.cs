using System;
using GOSTDoc.Core;
using Tesseract;

namespace GOSTDoc.Infrastructure;
public class TiffExtractor : ITextExtractor
{
    public bool CanExtract(string filePath) => 
        filePath.EndsWith(".tiff", StringComparison.OrdinalIgnoreCase) || 
        filePath.EndsWith(".tif", StringComparison.OrdinalIgnoreCase);
    
    public string ExtractText(string filePath)
    {
        var tessDataPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tessdata");
        if (!System.IO.File.Exists(System.IO.Path.Combine(tessDataPath, "rus.traineddata")))
        {
            return "ОШИБКА: Не найден локальный ресурс tessdata/rus.traineddata для русского OCR.";
        }

        try
        {
            using var engine = new TesseractEngine(tessDataPath, "rus", EngineMode.Default);
            using var img = Pix.LoadFromFile(filePath);
            using var page = engine.Process(img);
            return page.GetText();
        }
        catch (Exception ex)
        {
            return $"Ошибка OCR: {ex.Message}";
        }
    }
}