using System;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using GOSTDoc.Core;

namespace GOSTDoc.Infrastructure;

public class DocxExporter : IDocumentExporter
{
    public void ExportToDocx(string text, string filePath)
    {
        using var doc = WordprocessingDocument.Create(filePath, WordprocessingDocumentType.Document);
        var mainPart = doc.AddMainDocumentPart();
        mainPart.Document = new Document();
        var body = mainPart.Document.AppendChild(new Body());

        // Настройка страницы (Поля: Левое 30мм, Правое 15мм, Верхнее/Нижнее 20мм)
        var sectionProperties = new SectionProperties(
            new PageSize { Width = 11906, Height = 16838 }, // A4
            new PageMargin { Top = 1134, Right = 850, Bottom = 1134, Left = 1701, Header = 708, Footer = 708, Gutter = 0 }
        );
        var lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        
        foreach (var line in lines)
        {
            var p = new Paragraph();
            var run = new Run();
            var textElement = new Text(line) { Space = SpaceProcessingModeValues.Preserve };

            // Шрифт Times New Roman, 14pt
            var runProperties = new RunProperties(
                new RunFonts { Ascii = "Times New Roman", HighAnsi = "Times New Roman", EastAsia = "Times New Roman", ComplexScript = "Times New Roman" },
                new FontSize { Val = "28" }
            );

            var paragraphProperties = new ParagraphProperties(
                new SpacingBetweenLines { Line = "360", LineRule = LineSpacingRuleValues.Auto } // 1.5 интервал
            );

            if (line.StartsWith("## "))
            {
                textElement.Text = line.Substring(3);
                runProperties.Bold = new Bold();
                paragraphProperties.Justification = new Justification { Val = JustificationValues.Center };
                paragraphProperties.Indentation = new Indentation { Left = "0", FirstLine = "0" };
                if (paragraphProperties.SpacingBetweenLines != null)
                {
                    paragraphProperties.SpacingBetweenLines.Before = "240";
                    paragraphProperties.SpacingBetweenLines.After = "240";
                }
            }
            else if (line.StartsWith("### "))
            {
                textElement.Text = line.Substring(4);
                runProperties.Bold = new Bold();
                paragraphProperties.Justification = new Justification { Val = JustificationValues.Both };
                paragraphProperties.Indentation = new Indentation { FirstLine = "709" }; // 1.25 см
            }
            else
            {
                textElement.Text = line;
                paragraphProperties.Justification = new Justification { Val = JustificationValues.Both };
                paragraphProperties.Indentation = new Indentation { FirstLine = "709" }; // 1.25 см
            }

            p.AppendChild(paragraphProperties);
            run.AppendChild(runProperties);
            run.AppendChild(textElement);
            p.AppendChild(run);
            body.AppendChild(p);
        }
        // SectionProperties must be the final child of Body in WordprocessingML.
        body.AppendChild(sectionProperties);
    }
}