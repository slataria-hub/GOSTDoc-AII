using System;
using System.Text;
using GOSTDoc.Core;
using UglyToad.PdfPig;

namespace GOSTDoc.Infrastructure;
public class PdfExtractor : ITextExtractor
{
    public bool CanExtract(string filePath) => filePath.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase);
    public string ExtractText(string filePath)
    {
        using var document = PdfDocument.Open(filePath);
        var text = new StringBuilder();
        foreach (var page in document.GetPages())
        {
            if (!string.IsNullOrWhiteSpace(page.Text)) text.AppendLine(page.Text);
        }
        var extracted = text.ToString().Trim();
        return extracted.Length == 0
            ? "ОШИБКА: В PDF не найден текстовый слой. Возможно, это скан; требуется OCR перед импортом."
            : extracted;
    }
}