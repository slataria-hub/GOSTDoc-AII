using System;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using GOSTDoc.Core;

namespace GOSTDoc.Infrastructure;

public class DocumentGenerator
{
    private readonly ILocalLanguageModel _llm;
    private readonly NormControlEngine _normControl;

    public DocumentGenerator(ILocalLanguageModel llm, NormControlEngine normControl)
    {
        _llm = llm;
        _normControl = normControl;
    }

    public async Task<GenerationResult> GenerateAsync(IEnumerable<StandardEdition> standards, IEnumerable<SourceDocument> docs, string userPrompt)
    {
        var facts = BuildFacts(docs);
        var (requiredSections, writingRules) = BuildRules(standards);
        
        var systemPrompt = $@"Ты  технический писатель. Напиши документ строго по фактам.
ТРЕБОВАНИЯ К ЯЗЫКУ:
1. Весь текст пиши ТОЛЬКО НА РУССКОМ ЯЗЫКЕ.
2. Технические термины, названия ПО, бренды, языки программирования (например, Python, Nginx, Windows, API, SQL) оставляй в ИХ ОРИГИНАЛЬНОМ НАПИСАНИИ (на английском). НЕ переводи их дословно.

Ответ должен состоять из следующих разделов (заголовки с ##):
{requiredSections}

Требования к стилю:
{writingRules}

ПРАВИЛА:
1. Начни сразу с первого заголовка.
2. Не пиши вводных слов и не объясняй свои действия.
3. Если просят схему, нарисуй её с помощью кода SVG в блоке ```svg ... ``` внутри нужного раздела.
4. Если фактов нет, напиши ""ТРЕБУЕТ УТОЧНЕНИЯ"".";

        var prompt = $"<|im_start|>system\n{systemPrompt}<|im_end|>\n<|im_start|>user\nЗапрос: {userPrompt}\n\nФакты:\n{facts}<|im_end|>\n<|im_start|>assistant\n";

        var generatedText = await _llm.GenerateAsync(prompt);
        var findings = _normControl.ValidateDocument(generatedText, standards);

        return new GenerationResult { GeneratedText = generatedText, Findings = findings };
    }

    public async Task<string> RefineAsync(string currentText, string refinementPrompt)
    {
        var systemPrompt = @"Ты  редактор. Внеси изменения в текст. Выведи только полный исправленный текст без лишних слов. 
ТРЕБОВАНИЯ К ЯЗЫКУ:
1. Весь текст пиши ТОЛЬКО НА РУССКОМ ЯЗЫКЕ.
2. Технические термины, названия ПО, бренды (Python, Nginx, Windows и т.д.) оставляй БЕЗ ИЗМЕНЕНИЙ.
3. Если просят схему, используй ```svg ... ```.";

        var userPrompt = $"ТЕКУЩИЙ ТЕКСТ:\n{currentText}\n\nЧТО ИЗМЕНИТЬ:\n{refinementPrompt}";
        var prompt = $"<|im_start|>system\n{systemPrompt}<|im_end|>\n<|im_start|>user\n{userPrompt}<|im_end|>\n<|im_start|>assistant\n";

        return await _llm.GenerateAsync(prompt);
    }

    public async Task<string> HumanizeAsync(string text)
    {
        var systemPrompt = @"Ты  опытный инженер-документалист. Твоя задача  переписать текст так, чтобы он выглядел так, будто его написал человек, а не нейросеть.
ТРЕБОВАНИЯ К ЯЗЫКУ:
1. Весь текст пиши ТОЛЬКО НА РУССКОМ ЯЗЫКЕ. НЕ ПЕРЕВОДИ его на английский.
2. Технические термины, названия ПО, бренды, языки программирования (например, Python, Nginx, Windows, API) оставляй в ИХ ОРИГИНАЛЬНОМ НАПИСАНИИ. Не переводи их дословно.

ПРАВИЛА ПЕРЕПИСЫВАНИЯ:
1. Убери шаблонные фразы ИИ (например: 'В заключение', 'Важно отметить', 'Таким образом', 'Стоит подчеркнуть').
2. Сделай длину предложений разнообразной (чередуй короткие и длинные).
3. Избегай идеально ровных и параллельных списков, если они не требуются строго по ГОСТ.
4. Сохрани ВСЕ технические факты, цифры, названия и структуру заголовков.
5. Пиши сухим, но естественным инженерным языком. Выведи только готовый текст без своих комментариев.";

        var prompt = $"<|im_start|>system\n{systemPrompt}<|im_end|>\n<|im_start|>user\nТекст для переработки:\n{text}<|im_end|>\n<|im_start|>assistant\n";
        return await _llm.GenerateAsync(prompt);
    }

    public async Task<string> AnonymizeAsync(string text)
    {
        var systemPrompt = @"Ты специалист по обезличиванию технических документов.
Задача: заменить персональные и идентифицирующие сведения нейтральными устойчивыми маркерами, не меняя технический смысл.
Правила:
1. ФИО и личные имена заменяй на [ФИО-1], [ФИО-2] и далее; сохраняй один и тот же маркер для одного и того же человека.
2. Телефоны, электронную почту, домашние адреса, номера документов, банковских счетов и другие идентификаторы замени на подходящие маркеры, например [ТЕЛЕФОН-1], [EMAIL-1], [АДРЕС-1], [НОМЕР-ДОКУМЕНТА-1].
3. Названия организаций заменяй на [ОРГАНИЗАЦИЯ-1] только если они идентифицируют конкретного владельца/клиента и не являются техническим продуктом или стандартом.
4. Не меняй номера ГОСТов, модели оборудования, названия программ, версии ПО, технические параметры, формулы и команды.
5. Сохрани структуру, заголовки, таблицы в текстовом виде, цифры технических параметров и язык исходника.
6. Не добавляй пояснений. Верни только обезличенный текст.";
        var prompt = $"<|im_start|>system\n{systemPrompt}<|im_end|>\n<|im_start|>user\nОбезличь следующий текст:\n{text}<|im_end|>\n<|im_start|>assistant\n";
        return await _llm.GenerateAsync(prompt);
    }

    public async Task<List<ProofreadingError>> ProofreadAsync(string text, IEnumerable<StandardEdition> standards = null)
    {
        var standardsText = "";
        if (standards != null && standards.Any())
        {
            var (reqSecs, writeRules) = BuildRules(standards);
            standardsText = $"Также проверь соответствие следующим требованиям ГОСТ:\nСтруктура:\n{reqSecs}\nСтиль:\n{writeRules}";
        }

        var systemPrompt = $@"Ты  строгий редактор и эксперт по ГОСТ. 
Проанализируй текст и найди ошибки: орфографические, пунктуационные, грамматические, логические и несоответствия официально-деловому стилю.
{standardsText}
ТРЕБОВАНИЯ К ЯЗЫКУ:
1. Твой ответ (включая причины и рекомендации) должен быть ТОЛЬКО НА РУССКОМ ЯЗЫКЕ.
2. НЕ считай ошибкой написание технических терминов и названий ПО (Python, Nginx, Windows и т.д.) на английском языке. Это норма.

Верни ответ СТРОГО в формате JSON-массива (без markdown-тегов, без ```json):
[
  {{ ""original"": ""фрагмент с ошибкой"", ""suggestion"": ""как исправить"", ""reason"": ""почему это ошибка"" }}
]
Если ошибок нет, верни пустой массив [].";

        var prompt = $"<|im_start|>system\n{systemPrompt}<|im_end|>\n<|im_start|>user\nТекст для проверки:\n{text}<|im_end|>\n<|im_start|>assistant\n";

        var response = await _llm.GenerateAsync(prompt);
        
        try
        {
            response = response.Replace("```json", "").Replace("```", "").Trim();
            var startIdx = response.IndexOf('[');
            var endIdx = response.LastIndexOf(']');
            if (startIdx >= 0 && endIdx > startIdx)
            {
                response = response.Substring(startIdx, endIdx - startIdx + 1);
            }
            return JsonSerializer.Deserialize<List<ProofreadingError>>(response) ?? new List<ProofreadingError>();
        }
        catch
        {
            return new List<ProofreadingError> { new ProofreadingError { Original = "Ошибка парсинга", Suggestion = "Нейросеть вернула неверный формат", Reason = response } };
        }
    }

    private string BuildFacts(IEnumerable<SourceDocument> docs)
    {
        var sb = new StringBuilder();
        const int maxFactsCharacters = 24000;
        foreach (var doc in docs)
        {
            if (sb.Length >= maxFactsCharacters) break;
            var available = maxFactsCharacters - sb.Length;
            var snippetLength = Math.Min(2000, Math.Max(0, available - doc.FileName.Length - 20));
            if (snippetLength <= 0) break;
            var sourceText = doc.ExtractedText ?? string.Empty;
            var snippet = sourceText.Length > snippetLength ? sourceText.Substring(0, snippetLength) : sourceText;
            sb.AppendLine($"--- '{doc.FileName}' ---\n{snippet}\n");
        }
        if (docs.Any() && sb.Length >= maxFactsCharacters)
            sb.AppendLine("[Часть исходных материалов пропущена из-за ограничения объёма контекста модели.]");
        return sb.ToString();
    }

    private (string sections, string rules) BuildRules(IEnumerable<StandardEdition> standards)
    {
        var list = standards.ToList();
        var structural = list.SelectMany(s => s.Rules).Where(r => r.IsMandatory && r.Category == "Structure").Select(r => $"- {r.SectionName}").Distinct().ToList();
        
        if (!structural.Any())
        {
            structural = new List<string> { "- Назначение программы", "- Условия выполнения программы", "- Выполнение программы" };
        }

        var text = list.SelectMany(s => s.Rules).Where(r => !string.IsNullOrWhiteSpace(r.RuleText)).Select(r => $"- {r.RuleText}").Distinct();
        return (string.Join("\n", structural), string.Join("\n", text));
    }
}