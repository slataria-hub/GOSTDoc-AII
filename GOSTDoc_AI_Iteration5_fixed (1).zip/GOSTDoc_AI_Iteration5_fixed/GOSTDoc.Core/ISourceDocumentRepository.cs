using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GOSTDoc.Core;
public interface ISourceDocumentRepository
{
    Task InitializeAsync();
    Task AddAsync(SourceDocument doc);
    Task DeleteByProjectIdAsync(Guid projectId);
    Task<IEnumerable<SourceDocument>> GetByProjectIdAsync(Guid projectId);
}