using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using GOSTDoc.Core;
using GOSTDoc.Infrastructure;

namespace GOSTDoc.Desktop;
public class MainWindowViewModel : INotifyPropertyChanged
{
    private readonly IProjectRepository _projectRepo;
    private readonly ISourceDocumentRepository _docRepo;
    private readonly IStandardRepository _standardRepo;
    private readonly ITextExtractor[] _extractors;
    private DocumentGenerator _generator;
    private readonly IDocumentExporter _exporter;
    private ILocalLanguageModel _llm;

    public ObservableCollection<Project> Projects { get; } = new();
    public ObservableCollection<SourceDocument> Documents { get; } = new();
    public ObservableCollection<StandardEdition> Standards { get; } = new();
    public ObservableCollection<ValidationFinding> ValidationReport { get; } = new();
    public ObservableCollection<StandardEdition> SelectedStandards { get; } = new();
    
    public ObservableCollection<ProofreadingError> ProofreadingErrors { get; } = new();

    public bool HasProjects => Projects.Count > 0;
    public bool HasSelectedProject => SelectedProject != null;
    public bool HasSelectedGost => SelectedGost != null;
    public bool HasDocuments => Documents.Count > 0;
    public bool HasSelectedDocument => SelectedDocument != null;
    public bool HasStandards => Standards.Count > 0;
    public bool HasValidationFindings => ValidationReport.Count > 0;
    public bool HasProofreadingErrors => ProofreadingErrors.Count > 0;
    public bool HasAuditErrors => AuditErrors.Count > 0;

    // Свойства для вкладки Аудит
    public ObservableCollection<StandardEdition> AuditStandards { get; } = new();
    public ObservableCollection<ProofreadingError> AuditErrors { get; } = new();
    
    private string _auditText = string.Empty;
    public string AuditText
    {
        get => _auditText;
        set { _auditText = value; OnPropertyChanged(); OnPropertyChanged(nameof(AuditTextLength)); }
    }
    public int AuditTextLength => AuditText?.Length ?? 0;

    public ICommand CreateProjectCommand { get; }
    public string ModelPath { get; private set; } = string.Empty;
    private string _modelStatus = "Модель не выбрана";
    public string ModelStatus { get => _modelStatus; private set { _modelStatus = value; OnPropertyChanged(); } }
    public ICommand GenerateDocumentCommand { get; }
    public ICommand RefineDocumentCommand { get; }
    public ICommand ProofreadCommand { get; }
    public ICommand ApplyCorrectionCommand { get; }
    
    public ICommand StartRenameCommand { get; }
    public ICommand SaveRenameCommand { get; }
    public ICommand CancelRenameCommand { get; }
    public ICommand DeleteProjectCommand { get; }
    public ICommand ArchiveProjectCommand { get; }
    public string ArchiveButtonText => SelectedProject?.IsArchived == true ? "Восстановить" : "В архив";
    public ICommand DeleteGostCommand { get; }

    // Команды Аудита
    public ICommand ProofreadAuditCommand { get; }
    public ICommand HumanizeCommand { get; }
    public ICommand HumanizeAuditCommand { get; }
    public ICommand AnonymizeCommand { get; }
    public ICommand AnonymizeAuditCommand { get; }
    public ICommand ApplyAuditCorrectionCommand { get; }

    private Project? _selectedProject;
    public Project? SelectedProject
    {
        get => _selectedProject;
        set { _selectedProject = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasSelectedProject)); OnPropertyChanged(nameof(ArchiveButtonText)); IsRenaming = false; SelectedDocument = null; _ = LoadDocumentsAsync(); }
    }

    private SourceDocument? _selectedDocument;
    public SourceDocument? SelectedDocument
    {
        get => _selectedDocument;
        set { _selectedDocument = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasSelectedDocument)); }
    }

    private StandardEdition? _selectedGost;
    public StandardEdition? SelectedGost
    {
        get => _selectedGost;
        set { _selectedGost = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasSelectedGost)); }
    }

    private bool _isRenaming;
    public bool IsRenaming
    {
        get => _isRenaming;
        set { _isRenaming = value; OnPropertyChanged(); }
    }

    private string _editProjectName = "";
    public string EditProjectName
    {
        get => _editProjectName;
        set { _editProjectName = value; OnPropertyChanged(); }
    }

    private string _userPrompt = "Создай руководство оператора. Нарисуй структурную схему.";
    public string UserPrompt
    {
        get => _userPrompt;
        set { _userPrompt = value; OnPropertyChanged(); }
    }

    private string _refinePrompt = "";
    public string RefinePrompt
    {
        get => _refinePrompt;
        set { _refinePrompt = value; OnPropertyChanged(); }
    }

    private string _generatedDocumentText = string.Empty;
    public string GeneratedDocumentText
    {
        get => _generatedDocumentText;
        set { _generatedDocumentText = value; OnPropertyChanged(); OnPropertyChanged(nameof(GeneratedDocumentLength)); }
    }
    public int GeneratedDocumentLength => GeneratedDocumentText?.Length ?? 0;

    private bool _isGenerating;
    public bool IsGenerating
    {
        get => _isGenerating;
        set { _isGenerating = value; OnPropertyChanged(); }
    }

    private string _statusMessage = "Готово к работе. Данные хранятся локально.";
    public string StatusMessage
    {
        get => _statusMessage;
        private set { _statusMessage = value; OnPropertyChanged(); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public MainWindowViewModel()
    {
        Projects.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasProjects));
        Documents.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasDocuments));
        Standards.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasStandards));
        ValidationReport.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasValidationFindings));
        ProofreadingErrors.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasProofreadingErrors));
        AuditErrors.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasAuditErrors));
        var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var appFolder = Path.Combine(appData, "GOSTDocApp");
        Directory.CreateDirectory(appFolder);
        var dbPath = Path.Combine(appFolder, "gostdoc.db");

        _projectRepo = new SqliteProjectRepository(dbPath);
        _docRepo = new SqliteSourceDocumentRepository(dbPath);
        _standardRepo = new SqliteStandardRepository(dbPath);
        _extractors = new ITextExtractor[] { new TxtExtractor(), new PdfExtractor(), new DocxExtractor(), new TiffExtractor() };
        
        var settings = LocalAppSettings.Load();
        ModelPath = ResolveModelPath(settings.ModelPath);
        _llm = new LlamaSharpModel(ModelPath);
        _generator = new DocumentGenerator(_llm, new NormControlEngine());
        RefreshModelStatus();
        _exporter = new DocxExporter();

        CreateProjectCommand = new RelayCommand(_ => { _ = RunSafelyAsync(CreateProjectAsync, "создание проекта"); });
        GenerateDocumentCommand = new RelayCommand(_ => { _ = RunSafelyAsync(GenerateDocumentAsync, "генерация документа"); });
        RefineDocumentCommand = new RelayCommand(_ => { _ = RunSafelyAsync(RefineDocumentAsync, "доработка документа"); });
        ProofreadCommand = new RelayCommand(_ => { _ = RunSafelyAsync(ProofreadGeneratedAsync, "проверка текста"); });
        ApplyCorrectionCommand = new RelayCommand(obj => ApplyCorrection(obj));
        
        ProofreadAuditCommand = new RelayCommand(_ => { _ = RunSafelyAsync(ProofreadAuditAsync, "аудит документа"); });
        HumanizeCommand = new RelayCommand(_ => { _ = RunSafelyAsync(HumanizeGeneratedAsync, "переработка стиля"); });
        HumanizeAuditCommand = new RelayCommand(_ => { _ = RunSafelyAsync(HumanizeAuditAsync, "переработка стиля аудита"); });
        AnonymizeCommand = new RelayCommand(_ => { _ = RunSafelyAsync(AnonymizeGeneratedAsync, "обезличивание документа"); });
        AnonymizeAuditCommand = new RelayCommand(_ => { _ = RunSafelyAsync(AnonymizeAuditAsync, "обезличивание проверяемого документа"); });
        ApplyAuditCorrectionCommand = new RelayCommand(obj => ApplyAuditCorrection(obj));
        
        StartRenameCommand = new RelayCommand(_ => StartRename());
        SaveRenameCommand = new RelayCommand(_ => { _ = RunSafelyAsync(SaveRenameAsync, "переименование проекта"); });
        CancelRenameCommand = new RelayCommand(_ => IsRenaming = false);
        DeleteProjectCommand = new RelayCommand(_ => { _ = RunSafelyAsync(DeleteProjectAsync, "удаление проекта"); });
        ArchiveProjectCommand = new RelayCommand(_ => { _ = RunSafelyAsync(ArchiveProjectAsync, "изменение архива проекта"); });
        DeleteGostCommand = new RelayCommand(_ => { _ = RunSafelyAsync(DeleteGostAsync, "удаление стандарта"); });
        
        _ = LoadAllAsync();
    }

    private async Task RunSafelyAsync(Func<Task> action, string operationName)
    {
        try { await action(); }
        catch (Exception ex) { StatusMessage = $"Ошибка ({operationName}): {ex.Message}"; }
    }

    public void ConfigureModelPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        var fullPath = Path.GetFullPath(path);
        if (!File.Exists(fullPath)) { StatusMessage = "Файл модели не найден."; return; }
        if (!string.Equals(Path.GetExtension(fullPath), ".gguf", StringComparison.OrdinalIgnoreCase)) { StatusMessage = "Выберите файл локальной модели с расширением .gguf."; return; }
        ModelPath = fullPath;
        var settings = LocalAppSettings.Load();
        settings.ModelPath = ModelPath;
        settings.Save();
        // Модель загружается лениво при первом запросе. При смене пути создаём новый локальный адаптер.
        _llm = new LlamaSharpModel(ModelPath);
        _generator = new DocumentGenerator(_llm, new NormControlEngine());
        RefreshModelStatus();
        OnPropertyChanged(nameof(ModelPath));
    }

    private void RefreshModelStatus()
    {
        ModelStatus = !string.IsNullOrWhiteSpace(ModelPath) && File.Exists(ModelPath)
            ? $"Готова к запуску\n{Path.GetFileName(ModelPath)}"
            : "Файл модели не найден. Выберите GGUF-файл.";
    }

    private static string ResolveModelPath(string configuredPath)
    {
        if (!string.IsNullOrWhiteSpace(configuredPath) && File.Exists(configuredPath)) return configuredPath;
        var fileName = "Qwen2.5-7B-Instruct-Q4_K_M.gguf";
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Models", fileName),
            Path.Combine(AppContext.BaseDirectory, fileName),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GOSTDocApp", "Models", fileName),
            @"C:\GOSTDoc\Models\Qwen2.5-7B-Instruct-Q4_K_M.gguf"
        };
        return candidates.FirstOrDefault(File.Exists) ?? candidates[0];
    }

    private async Task LoadAllAsync()
    {
        try
        {
            await _projectRepo.InitializeAsync();
            await _docRepo.InitializeAsync();
            await _standardRepo.InitializeAsync();
            await LoadProjectsAsync();
            await LoadStandardsAsync();
            StatusMessage = "Рабочая область загружена. Сетевое подключение для работы приложения не требуется.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось открыть локальную базу данных: {ex.Message}"; }
    }

    private async Task LoadProjectsAsync()
    {
        var projs = await _projectRepo.GetAllProjectsAsync();
        Projects.Clear();
        foreach(var p in projs) Projects.Add(p);
    }

    private async Task LoadStandardsAsync()
    {
        var stds = await _standardRepo.GetAllStandardsAsync();
        Standards.Clear();
        foreach (var s in stds) Standards.Add(s);
    }

    public void UpdateSelectedStandards(IEnumerable<object> selectedItems)
    {
        SelectedStandards.Clear();
        foreach (var item in selectedItems)
            if (item is StandardEdition std) SelectedStandards.Add(std);
    }

    public void UpdateAuditStandards(IEnumerable<object> selectedItems)
    {
        AuditStandards.Clear();
        foreach (var item in selectedItems)
            if (item is StandardEdition std) AuditStandards.Add(std);
    }

    private async Task LoadDocumentsAsync()
    {
        Documents.Clear();
        SelectedDocument = null;
        if (SelectedProject == null) return;
        try
        {
            var projectId = SelectedProject.Id;
            var docs = await _docRepo.GetByProjectIdAsync(projectId);
            if (SelectedProject?.Id != projectId) return;
            foreach (var d in docs) Documents.Add(d);
            SelectedDocument = Documents.FirstOrDefault();
        }
        catch (Exception ex) { StatusMessage = $"Не удалось загрузить документы проекта: {ex.Message}"; }
    }

    private async Task CreateProjectAsync()
    {
        var projectPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GOSTDocApp", "Projects", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(projectPath);
        var newProj = await _projectRepo.CreateProjectAsync($"Проект от {DateTime.Now:HH:mm:ss}", "Новый", projectPath);
        Projects.Add(newProj);
        SelectedProject = newProj;
        StatusMessage = $"Создан проект «{newProj.Name}».";
    }

    private void StartRename()
    {
        if (SelectedProject == null) return;
        EditProjectName = SelectedProject.Name;
        IsRenaming = true;
    }

    private async Task SaveRenameAsync()
    {
        if (SelectedProject == null || string.IsNullOrWhiteSpace(EditProjectName)) return;
        SelectedProject.Name = EditProjectName;
        await _projectRepo.UpdateProjectAsync(SelectedProject);
        var index = Projects.IndexOf(SelectedProject);
        if (index >= 0) Projects[index] = SelectedProject; 
        IsRenaming = false;
    }

    private async Task DeleteProjectAsync()
    {
        if (SelectedProject == null) return;
        var projectToDelete = SelectedProject;
        await _docRepo.DeleteByProjectIdAsync(projectToDelete.Id);
        await _projectRepo.DeleteProjectAsync(projectToDelete.Id);
        Projects.Remove(projectToDelete);
        SelectedProject = null;
        Documents.Clear();
        SelectedDocument = null;
        StatusMessage = $"Проект «{projectToDelete.Name}» и связанные записи удалены.";
    }

    private async Task ArchiveProjectAsync()
    {
        if (SelectedProject == null) return;
        SelectedProject.IsArchived = !SelectedProject.IsArchived;
        OnPropertyChanged(nameof(ArchiveButtonText));
        await _projectRepo.UpdateProjectAsync(SelectedProject);
        var index = Projects.IndexOf(SelectedProject);
        if (index >= 0) Projects[index] = SelectedProject;
    }

    private async Task DeleteGostAsync()
    {
        if (SelectedGost == null) return;
        await _standardRepo.DeleteStandardAsync(SelectedGost.Id);
        await LoadStandardsAsync();
        SelectedGost = null;
        SelectedStandards.Clear();
        AuditStandards.Clear();
        StatusMessage = "Стандарт удалён из локальной библиотеки.";
    }

    private async Task GenerateDocumentAsync()
    {
        if (IsGenerating) return;
        if (SelectedProject == null)
        {
            StatusMessage = "Сначала создайте или выберите проект.";
            return;
        }
        if (!SelectedStandards.Any())
        {
            StatusMessage = "Выберите хотя бы один ГОСТ в списке применимых стандартов.";
            return;
        }
        if (string.IsNullOrWhiteSpace(UserPrompt))
        {
            StatusMessage = "Введите задание для генерации документа.";
            return;
        }

        IsGenerating = true;
        StatusMessage = "Генерируется документ с использованием локальной модели…";
        ValidationReport.Clear();
        ProofreadingErrors.Clear();

        try
        {
            var result = await Task.Run(() => _generator.GenerateAsync(SelectedStandards, Documents, UserPrompt));
            GeneratedDocumentText = result.GeneratedText;
            foreach (var finding in result.Findings) ValidationReport.Add(finding);
            StatusMessage = $"Генерация завершена. Предварительных замечаний нормоконтроля: {ValidationReport.Count}.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось завершить генерацию: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    private async Task ProofreadGeneratedAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(GeneratedDocumentText)) { StatusMessage = "Сначала подготовьте или вставьте текст документа."; return; }
        IsGenerating = true;
        ProofreadingErrors.Clear();
        
        try
        {
            var errors = await Task.Run(() => _generator.ProofreadAsync(GeneratedDocumentText, SelectedStandards));
            foreach (var err in errors) ProofreadingErrors.Add(err);
            StatusMessage = $"Проверка завершена. Найдено замечаний: {ProofreadingErrors.Count}.";
        }
        catch (Exception ex) { ProofreadingErrors.Add(new ProofreadingError { Original = "Системная ошибка", Suggestion = ex.Message, Reason = "Сбой при проверке" }); StatusMessage = "Проверка завершилась с ошибкой."; }
        finally { IsGenerating = false; }
    }

    private void ApplyCorrection(object? errorObj)
    {
        if (errorObj is ProofreadingError error && !string.IsNullOrWhiteSpace(error.Original))
        {
            if (GeneratedDocumentText.Contains(error.Original, StringComparison.Ordinal))
            {
                GeneratedDocumentText = GeneratedDocumentText.Replace(error.Original, error.Suggestion, StringComparison.Ordinal);
                ProofreadingErrors.Remove(error);
                StatusMessage = "Исправление применено к тексту документа.";
            }
            else StatusMessage = "Фрагмент для исправления больше не найден в текущем тексте.";
        }
    }

    private async Task RefineDocumentAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(GeneratedDocumentText)) { StatusMessage = "Сначала подготовьте или вставьте текст документа."; return; }
        if (string.IsNullOrWhiteSpace(RefinePrompt)) { StatusMessage = "Опишите, что нужно изменить в документе."; return; }
        IsGenerating = true;
        var oldText = GeneratedDocumentText;
        StatusMessage = "Локальная модель вносит правки в документ…";

        try
        {
            var refined = await Task.Run(() => _generator.RefineAsync(oldText, RefinePrompt));
            GeneratedDocumentText = refined;
            RefinePrompt = "";
            StatusMessage = "Доработка документа завершена.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось доработать документ: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    private async Task AnonymizeGeneratedAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(GeneratedDocumentText)) { StatusMessage = "Сначала подготовьте или вставьте текст документа."; return; }
        IsGenerating = true;
        var original = GeneratedDocumentText;
        StatusMessage = "Локальная модель обезличивает идентифицирующие сведения…";
        try
        {
            GeneratedDocumentText = await Task.Run(() => _generator.AnonymizeAsync(original));
            StatusMessage = "Обезличивание завершено. Проверьте результат перед экспортом.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось обезличить документ: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    private async Task AnonymizeAuditAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(AuditText)) { StatusMessage = "Загрузите документ или вставьте текст для обезличивания."; return; }
        IsGenerating = true;
        var original = AuditText;
        StatusMessage = "Локальная модель обезличивает проверяемый текст…";
        try
        {
            AuditText = await Task.Run(() => _generator.AnonymizeAsync(original));
            StatusMessage = "Обезличивание завершено. Проверьте результат перед экспортом.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось обезличить текст аудита: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    // --- Логика Аудита ---

    public async Task LoadAuditFileAsync(string filePath)
    {
        var extractor = _extractors.FirstOrDefault(x => x.CanExtract(filePath));
        if (extractor == null)
        {
            StatusMessage = "Формат файла не поддерживается. Используйте PDF, DOCX, TXT или TIFF.";
            return;
        }

        try
        {
            var text = await Task.Run(() => extractor.ExtractText(filePath));
            if (string.IsNullOrWhiteSpace(text) || text.StartsWith("ОШИБКА", StringComparison.OrdinalIgnoreCase) || text.StartsWith("Ошибка OCR", StringComparison.OrdinalIgnoreCase))
            {
                StatusMessage = string.IsNullOrWhiteSpace(text) ? "В файле не найден текст. Для сканированного PDF потребуется OCR." : text;
                return;
            }
            AuditText = text;
            AuditErrors.Clear();
            StatusMessage = $"Документ загружен для аудита: {Path.GetFileName(filePath)}.";
        }
        catch (Exception ex)
        {
            StatusMessage = $"Не удалось прочитать документ для аудита: {ex.Message}";
        }
    }

    private async Task HumanizeGeneratedAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(GeneratedDocumentText)) { StatusMessage = "Сначала подготовьте или вставьте текст документа."; return; }
        IsGenerating = true;
        var oldText = GeneratedDocumentText;
        StatusMessage = "Локальная модель обрабатывает текст…";

        try
        {
            var humanized = await Task.Run(() => _generator.HumanizeAsync(oldText));
            GeneratedDocumentText = humanized;
            StatusMessage = "Обработка текста завершена.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось обработать текст: {ex.Message}"; }
        finally { IsGenerating = false; }
    }

    private async Task HumanizeAuditAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(AuditText)) { StatusMessage = "Загрузите документ или вставьте текст для обработки."; return; }
        IsGenerating = true;
        var oldText = AuditText;
        StatusMessage = "Локальная модель обрабатывает текст аудита…";

        try
        {
            var humanized = await Task.Run(() => _generator.HumanizeAsync(oldText));
            AuditText = humanized;
            StatusMessage = "Обработка текста аудита завершена.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось обработать текст аудита: {ex.Message}"; }
        finally { IsGenerating = false; }
    }
    private async Task ProofreadAuditAsync()
    {
        if (IsGenerating) return;
        if (string.IsNullOrWhiteSpace(AuditText)) { StatusMessage = "Загрузите документ или вставьте текст для проверки."; return; }
        if (!AuditStandards.Any()) { StatusMessage = "Выберите хотя бы один ГОСТ для проверки."; return; }
        IsGenerating = true;
        AuditErrors.Clear();

        try
        {
            var errors = await Task.Run(() => _generator.ProofreadAsync(AuditText, AuditStandards));
            foreach (var err in errors) AuditErrors.Add(err);
            StatusMessage = $"Аудит завершён. Найдено замечаний: {AuditErrors.Count}.";
        }
        catch (Exception ex) { AuditErrors.Add(new ProofreadingError { Original = "Системная ошибка", Suggestion = ex.Message, Reason = "Сбой при проверке" }); StatusMessage = "Аудит завершился с ошибкой."; }
        finally { IsGenerating = false; }
    }

    private void ApplyAuditCorrection(object? errorObj)
    {
        if (errorObj is ProofreadingError error && !string.IsNullOrWhiteSpace(error.Original))
        {
            if (AuditText.Contains(error.Original, StringComparison.Ordinal))
            {
                AuditText = AuditText.Replace(error.Original, error.Suggestion, StringComparison.Ordinal);
                AuditErrors.Remove(error);
                StatusMessage = "Исправление применено к проверяемому документу.";
            }
            else StatusMessage = "Фрагмент для исправления больше не найден в текущем тексте.";
        }
    }

    public void ExportProjectToJson(string filePath)
    {
        if (SelectedProject == null) { StatusMessage = "Выберите проект для экспорта."; return; }
        try
        {
            var data = new
            {
                SchemaVersion = 1,
                ExportedAt = DateTimeOffset.Now,
                Project = SelectedProject,
                Documents = Documents,
                SelectedStandards,
                GeneratedText = GeneratedDocumentText,
                ValidationReport,
                AuditText,
                AuditStandards,
                AuditErrors
            };
            var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
            File.WriteAllText(filePath, json);
            StatusMessage = $"Проект экспортирован в JSON: {Path.GetFileName(filePath)}.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось экспортировать проект: {ex.Message}"; }
    }

    public void ExportDocument(string filePath, string? customText = null)
    {
        var text = customText ?? GeneratedDocumentText;
        if (string.IsNullOrWhiteSpace(text))
        {
            StatusMessage = "Нечего экспортировать: текст документа пуст.";
            return;
        }
        try
        {
            _exporter.ExportToDocx(text, filePath);
            StatusMessage = $"Документ сохранён: {Path.GetFileName(filePath)}.";
        }
        catch (Exception ex) { StatusMessage = $"Не удалось сохранить DOCX: {ex.Message}"; }
    }

    public async Task ImportFilesAsync(string[] filePaths)
    {
        if (SelectedProject == null) { StatusMessage = "Сначала создайте или выберите проект для импорта исходных документов."; return; }
        foreach (var path in filePaths)
        {
            var extractor = _extractors.FirstOrDefault(x => x.CanExtract(path));
            if (extractor == null)
            {
                StatusMessage = $"Формат {Path.GetExtension(path)} не поддерживается: {Path.GetFileName(path)}.";
                continue;
            }

            try
            {
                var hash = CalculateSha256(path);
                var text = await Task.Run(() => extractor.ExtractText(path));
                if (string.IsNullOrWhiteSpace(text) || text.StartsWith("ОШИБКА", StringComparison.OrdinalIgnoreCase) || text.StartsWith("Ошибка OCR", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException(string.IsNullOrWhiteSpace(text) ? "Текст не найден. Для сканированных PDF требуется OCR." : text);
                var doc = new SourceDocument { ProjectId = SelectedProject.Id, FileName = Path.GetFileName(path), FileHash = hash, ExtractedText = text, Status = "Извлечено" };
                await _docRepo.AddAsync(doc);
                Documents.Add(doc);
                SelectedDocument = doc;
                StatusMessage = $"Импортирован исходный файл: {doc.FileName}.";
            }
            catch (Exception ex)
            {
                var failedDocument = new SourceDocument { FileName = Path.GetFileName(path), Status = "Ошибка", ExtractedText = ex.Message, ProjectId = SelectedProject.Id };
                Documents.Add(failedDocument);
                SelectedDocument = failedDocument;
                StatusMessage = $"Не удалось импортировать {Path.GetFileName(path)}: {ex.Message}";
            }
        }
    }

    public async Task ImportStandardJsonAsync(string filePath)
    {
        try
        {
            var json = await File.ReadAllTextAsync(filePath);
            var standard = System.Text.Json.JsonSerializer.Deserialize<StandardEdition>(json,
                new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (standard == null || string.IsNullOrWhiteSpace(standard.Code) || string.IsNullOrWhiteSpace(standard.Title))
                throw new InvalidDataException("JSON должен содержать поля Code и Title.");
            standard.Rules ??= new List<NormativeRule>();
            if (standard.Rules.Count == 0)
                throw new InvalidDataException("В JSON не найден список Rules с нормативными требованиями.");
            if (standard.Id == Guid.Empty) standard.Id = Guid.NewGuid();
            foreach (var rule in standard.Rules) rule.StandardEditionId = standard.Id;
            var normalizedJson = System.Text.Json.JsonSerializer.Serialize(standard);
            await _standardRepo.ImportJsonPackAsync(normalizedJson);
            await LoadStandardsAsync();
            SelectedGost = Standards.FirstOrDefault(x => string.Equals(x.Code, standard.Code, StringComparison.OrdinalIgnoreCase));
            StatusMessage = $"Импортирован JSON-пакет {standard.Code}: правил — {standard.Rules.Count}.";
        }
        catch (Exception ex)
        {
            StatusMessage = $"Не удалось импортировать JSON-пакет: {ex.Message}";
        }
    }

    public async Task ImportStandardFromFileAsync(string filePath)
    {
        var extractor = _extractors.FirstOrDefault(x => x.CanExtract(filePath));
        if (extractor == null) 
        {
            StatusMessage = $"Формат {Path.GetExtension(filePath)} не поддерживается.";
            return;
        }

        StatusMessage = $"Чтение нормативного документа: {Path.GetFileName(filePath)}…";

        try
        {
            var text = await Task.Run(() => extractor.ExtractText(filePath));
            if (string.IsNullOrWhiteSpace(text) || text.StartsWith("Ошибка", StringComparison.OrdinalIgnoreCase) || text.StartsWith("ОШИБКА", StringComparison.OrdinalIgnoreCase))
            {
                StatusMessage = $"Не удалось извлечь текст из {Path.GetFileName(filePath)}.";
                return;
            }

            var snippet = text.Length > 15000 ? text.Substring(0, 15000) : text;

            StatusMessage = $"Локальная модель анализирует нормативный документ: {Path.GetFileName(filePath)}…";
            
            var prompt = $"<|im_start|>system\nТы  эксперт по ГОСТ. Твоя задача  проанализировать текст стандарта и извлечь обязательные разделы и правила оформления. Верни ответ СТРОГО в формате JSON (без markdown-разметки и без ```json):\n{{\n  \"Code\": \"Номер ГОСТа\",\n  \"Title\": \"Название\",\n  \"Rules\": [\n    {{ \"SectionName\": \"Раздел\", \"IsMandatory\": true, \"Category\": \"Structure\", \"RuleText\": \"\" }},\n    {{ \"SectionName\": \"Текст\", \"IsMandatory\": false, \"Category\": \"Text\", \"RuleText\": \"Правило\" }}\n  ]\n}}\n<|im_end|>\n<|im_start|>user\nТекст стандарта:\n{snippet}<|im_end|>\n<|im_start|>assistant\n";
            
            var aiResponse = await _llm.GenerateAsync(prompt);
            
            aiResponse = aiResponse.Replace("```json", "").Replace("```", "").Trim();
            var startIdx = aiResponse.IndexOf('{');
            var endIdx = aiResponse.LastIndexOf('}');
            if (startIdx >= 0 && endIdx > startIdx) aiResponse = aiResponse.Substring(startIdx, endIdx - startIdx + 1);

            var newStandard = System.Text.Json.JsonSerializer.Deserialize<StandardEdition>(aiResponse, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            
            if (newStandard != null)
                newStandard.Rules ??= new List<NormativeRule>();

            if (newStandard != null && newStandard.Rules.Count > 0)
            {
                newStandard.Id = Guid.NewGuid();
                foreach(var r in newStandard.Rules) r.StandardEditionId = newStandard.Id;
                
                if (string.IsNullOrWhiteSpace(newStandard.Code) || newStandard.Code == "Номер ГОСТа")
                    newStandard.Code = Path.GetFileNameWithoutExtension(filePath);
                if (string.IsNullOrWhiteSpace(newStandard.Title))
                    newStandard.Title = Path.GetFileNameWithoutExtension(filePath);

                var json = System.Text.Json.JsonSerializer.Serialize(newStandard);
                await _standardRepo.ImportJsonPackAsync(json);
                await LoadStandardsAsync();
                
                StatusMessage = $"Добавлен стандарт {newStandard.Code}; извлечено правил: {newStandard.Rules.Count}.";
            }
            else
            {
                StatusMessage = $"Не удалось распознать нормативные правила в {Path.GetFileName(filePath)}.";
            }
        }
        catch (Exception ex)
        {
            StatusMessage = $"Ошибка импорта {Path.GetFileName(filePath)}: {ex.Message}";
        }
    }

    private string CalculateSha256(string filePath)
    {
        using var stream = File.OpenRead(filePath);
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(stream));
    }

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

public class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    public RelayCommand(Action<object?> execute) => _execute = execute;
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => true; 
    public void Execute(object? parameter) => _execute(parameter);
}