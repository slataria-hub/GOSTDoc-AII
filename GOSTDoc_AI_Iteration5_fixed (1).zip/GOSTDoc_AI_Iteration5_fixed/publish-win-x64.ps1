# Упрощённый скрипт. Для полного лога, тестов и проверки AVX-папок используйте build-and-publish.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $root 'build-and-publish.ps1') @args
