#Requires -Version 5.1
<#
.SYNOPSIS
  Восстановление, сборка, тесты и публикация ГОСТ-Документатор AI (Windows x64, self-contained).

.DESCRIPTION
  Останавливается на первой ошибке. Пишет полный журнал в build-logs\.
  НЕ скрывает NETSDK1152 через ErrorOnDuplicatePublishOutputFiles=false.
  Исправление дубликатов LLamaSharp — в GOSTDoc.Desktop.csproj (target PreserveLlamaSharpCpuVariantFolders).

.PARAMETER SkipTests
  Пропустить unit-тесты.

.PARAMETER ModelPath
  Путь к GGUF-модели для копирования в publish\Models (необязательно).
#>
param(
    [switch]$SkipTests,
    [string]$ModelPath = 'C:\GOSTDoc\Models\Qwen2.5-7B-Instruct-Q4_K_M.gguf'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$solution = Join-Path $root 'GOSTDoc.sln'
$desktopProject = Join-Path $root 'GOSTDoc.Desktop\GOSTDoc.Desktop.csproj'
$output = Join-Path $root 'publish\win-x64'
$logDir = Join-Path $root 'build-logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$logFile = Join-Path $logDir "build-publish-$stamp.log"

function Invoke-DotNet {
    param([string[]]$Args)
    Write-Host ("dotnet " + ($Args -join ' ')) -ForegroundColor DarkGray
    & dotnet @Args 2>&1 | Tee-Object -FilePath $logFile -Append
    if ($LASTEXITCODE -ne 0) {
        throw "Команда завершилась с кодом $LASTEXITCODE : dotnet $($Args -join ' ')"
    }
}

try {
    Start-Transcript -Path (Join-Path $logDir "transcript-$stamp.txt") -Force | Out-Null

    if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
        throw 'Не найден .NET SDK. Установите .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0'
    }

    $sdk = (dotnet --list-sdks 2>$null | Select-String '^8\.') 
    if (-not $sdk) {
        Write-Warning 'SDK 8.x не найден в списке. Убедитесь, что установлен .NET 8 SDK.'
    }

    Write-Host "`n[1/4] Восстановление NuGet-зависимостей..." -ForegroundColor Yellow
    Invoke-DotNet @('restore', $solution)

    Write-Host "`n[2/4] Сборка Release..." -ForegroundColor Yellow
    Invoke-DotNet @('build', $solution, '-c', 'Release', '--no-restore')

    if (-not $SkipTests) {
        Write-Host "`n[3/4] Запуск тестов..." -ForegroundColor Yellow
        Invoke-DotNet @('test', $solution, '-c', 'Release', '--no-build', '--no-restore')
    } else {
        Write-Warning 'Тесты пропущены по параметру -SkipTests.'
    }

    Write-Host "`n[4/4] Публикация self-contained Windows x64..." -ForegroundColor Yellow
    if (Test-Path $output) {
        Remove-Item $output -Recurse -Force
    }
    New-Item -ItemType Directory -Path $output -Force | Out-Null

    Invoke-DotNet @(
        'publish', $desktopProject,
        '-c', 'Release',
        '-r', 'win-x64',
        '--self-contained', 'true',
        '-p:PublishSingleFile=false',
        '-o', $output
    )

    # tessdata
    if (Test-Path (Join-Path $root 'tessdata\rus.traineddata')) {
        $tessOut = Join-Path $output 'tessdata'
        New-Item -ItemType Directory -Path $tessOut -Force | Out-Null
        Copy-Item (Join-Path $root 'tessdata\*') $tessOut -Recurse -Force
        Write-Host 'tessdata скопированы.' -ForegroundColor Green
    } else {
        Write-Warning 'Не найдены tessdata\rus.traineddata: русский OCR может быть недоступен.'
    }

    # Модель (опционально)
    if (Test-Path $ModelPath) {
        $modelOut = Join-Path $output 'Models'
        New-Item -ItemType Directory -Path $modelOut -Force | Out-Null
        Copy-Item $ModelPath (Join-Path $modelOut (Split-Path $ModelPath -Leaf)) -Force
        Write-Host "Локальная модель скопирована: $ModelPath" -ForegroundColor Green
    } else {
        Write-Warning "GGUF-модель не найдена по пути '$ModelPath'. Выберите файл в приложении."
    }

    $exe = Join-Path $output 'GOSTDoc.Desktop.exe'
    if (-not (Test-Path $exe)) {
        throw "Публикация завершилась без ожидаемого файла $exe. Смотрите журнал: $logFile"
    }

    # Проверка наличия подпапок AVX (если native DLL попали в publish)
    $nativeRoot = Join-Path $output 'runtimes\win-x64\native'
    if (Test-Path $nativeRoot) {
        $variants = @('avx', 'avx2', 'avx512', 'noavx') | Where-Object { Test-Path (Join-Path $nativeRoot $_) }
        Write-Host "Папки native-вариантов LLamaSharp: $($variants -join ', ')" -ForegroundColor Cyan
        if (-not $variants) {
            Write-Warning 'Подпапки avx/avx2 не найдены — проверьте, что target PreserveLlamaSharpCpuVariantFolders сработал (см. журнал).'
        }
    }

    Write-Host "`nУСПЕХ: публикация создана в $output" -ForegroundColor Green
    Write-Host "EXE: $exe"
    Write-Host "Журнал: $logFile"
    Write-Host 'Дальше: запустите GOSTDoc.Desktop.exe, создайте проект, импортируйте файлы, выберите GGUF при необходимости.'
}
catch {
    Write-Host "`nСБОЙ: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Полный журнал: $logFile" -ForegroundColor Yellow
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
}
