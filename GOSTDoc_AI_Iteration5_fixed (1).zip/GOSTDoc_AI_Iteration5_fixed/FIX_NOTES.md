# Исправление Iteration 5 — NETSDK1152 (LLamaSharp)

## Что было сломано
При `dotnet publish -r win-x64 --self-contained true` возникала ошибка:

```
NETSDK1152: Found multiple publish output files with the same relative path
```

Причина: пакет `LLamaSharp.Backend.Cpu 0.17.0` содержит несколько копий одних и тех же нативных DLL
(`ggml.dll`, `llama.dll`, `llava_shared.dll` и т.п.) в папках:

- `runtimes/win-x64/native/`
- `runtimes/win-x64/native/avx/`
- `runtimes/win-x64/native/avx2/`
- `runtimes/win-x64/native/avx512/`
- (иногда `noavx`)

SDK при публикации «схлопывал» RelativePath до имени файла и считал их конфликтующими дубликатами.

## Что изменено
Файл: `GOSTDoc.Desktop/GOSTDoc.Desktop.csproj`

Добавлен MSBuild target `PreserveLlamaSharpCpuVariantFolders`, который **до** копирования в publish
восстанавливает RelativePath с подпапками `avx` / `avx2` / `avx512` / `noavx`.

- **Не** используется `ErrorOnDuplicatePublishOutputFiles=false` (это маскировало бы ошибку и оставляло бы случайный один DLL).
- Нативные варианты CPU **сохраняются**, runtime LLamaSharp по-прежнему может выбрать подходящий AVX.

Также обновлён скрипт `build-and-publish.ps1` (лог в `build-logs\`, останов при ошибке, проверка папок native).

## Что не проверялось здесь
В этой среде **нет** Windows и .NET 8 SDK. Компиляция, тесты и запуск Avalonia **не выполнялись**.
Проверку нужно сделать на вашем ПК с Windows.

## Как проверить на Windows (минимум шагов)

1. Установите [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0), если ещё нет.
2. Распакуйте эту папку `GOSTDoc_AI_Iteration5_fixed` куда удобно (например `C:\GOSTDoc\src`).
3. Откройте PowerShell в этой папке и выполните:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\build-and-publish.ps1
```

(Модель GGUF не обязательна на этом шаге. Если она лежит не в `C:\GOSTDoc\Models\...`, передайте путь:
`.\build-and-publish.ps1 -ModelPath "D:\Models\your.gguf"`.)

4. При успехе появится `publish\win-x64\GOSTDoc.Desktop.exe`.
5. Запустите EXE, создайте проект, импортируйте TXT/DOCX, при необходимости укажите GGUF в интерфейсе.

Если снова появится NETSDK1152 — пришлите **полный** текст из `build-logs\build-publish-*.log` (один файл), без ручного редактирования csproj.
